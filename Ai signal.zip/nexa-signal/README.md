# NEXA Signal Desk

ផ្ទាំង AI សញ្ញាជួញដូរ — ទិន្នន័យទីផ្សារផ្ទាល់, សូចនាករ RSI / MACD / MA / Bollinger, សញ្ញាទិញ-លក់, គណនីក្រដាស, និង Telegram Bot។

Educational paper desk. **Not financial advice.**

## រចនាសម្ព័ន្ធ

```
nexa-signal/
├── backend/                 Python FastAPI
│   ├── app/
│   │   ├── main.py          REST API + scheduler
│   │   ├── market.py        Live OHLC (OKX → Coinbase fallback)
│   │   ├── indicators.py    RSI, MACD, SMA, EMA, BB, ATR
│   │   ├── engine.py        Signal scoring
│   │   ├── telegram_bot.py  Auto dispatch BUY/SELL
│   │   └── database.py      SQLite demo (same tables as Postgres)
│   ├── schema.sql           PostgreSQL production schema
│   └── bot.py               Interactive Telegram commands
└── frontend/                React + Tailwind + TradingView charts
```

## 1. Frontend

React (Vite) + Tailwind។ ផ្ទាំងងងឹតបែប desk: តារាងទៀន, តុល្យភាពគណនី, បញ្ជីសញ្ញា, ផែនទី RSI, Telegram outbox។ ភាសា ខ្មែរ / English។

## 2. Backend

រៀងរាល់ 60 វិនាទី ទាញទៀន 1H របស់ BTC ETH SOL XRP DOGE ADA AVAX LINK LTC DOT แล้วគណនាសូចនាករ។ សញ្ញាកើតពេលមានយ៉ាងហោចពីរកត្តាយល់ស្រប (RSI, MACD cross, EMA trend, Bollinger)។

## 3. Telegram Bot

- ស្កេនហើយផ្ញើសារទៅ Group/Channel ដោយស្វ័យប្រវត្តិ
- បើគ្មាន token — សារចូលប្រអប់ចេញក្នុង Dashboard (ម៉ូដសាក)
- `python bot.py` សម្រាប់ពាក្យបញ្ជា `/start` `/signals` `/subscribe`

បង្កើតបូតតាម [@BotFather](https://t.me/BotFather) แล้วដាក់ token + chat id ក្នុងទំព័រ Telegram។

## 4. Database

`backend/schema.sql` — PostgreSQL។ Demo ប្រើ SQLite `backend/data/nexa.db` តារាងដូចគ្នា:

`users` `watchlists` `accounts` `candles` `signals` `positions` `telegram_logs` `app_settings`

## រត់ក្នុងម៉ាស៊ីន

```bash
# backend
cd backend
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000

# frontend
cd frontend
npm install
npm run dev
```

Dashboard: Vite port 5173 (proxy `/api` → `:8000`).
