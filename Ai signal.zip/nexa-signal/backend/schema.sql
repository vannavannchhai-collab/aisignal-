-- =============================================================================
-- NEXA Signal Desk  ·  PostgreSQL schema
-- Stores users, paper accounts, OHLCV cache, generated signals, positions,
-- and Telegram delivery logs. SQLite used in the demo maps 1:1 to these tables.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ---------------------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------------------
CREATE TABLE users (
    id              BIGSERIAL PRIMARY KEY,
    username        VARCHAR(64)  NOT NULL UNIQUE,
    email           VARCHAR(255) UNIQUE,
    password_hash   VARCHAR(255),
    display_name    VARCHAR(128) NOT NULL,
    language        VARCHAR(8)   NOT NULL DEFAULT 'km',
    timezone        VARCHAR(64)  NOT NULL DEFAULT 'Asia/Phnom_Penh',
    telegram_chat_id VARCHAR(64),
    telegram_enabled BOOLEAN     NOT NULL DEFAULT FALSE,
    role            VARCHAR(16)  NOT NULL DEFAULT 'trader'
                    CHECK (role IN ('trader', 'admin', 'viewer')),
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_login_at   TIMESTAMPTZ
);

CREATE INDEX idx_users_telegram ON users (telegram_chat_id)
    WHERE telegram_chat_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Watchlist
-- ---------------------------------------------------------------------------
CREATE TABLE watchlists (
    id          BIGSERIAL PRIMARY KEY,
    user_id     BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    symbol      VARCHAR(32)  NOT NULL,
    sort_order  INTEGER      NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, symbol)
);

-- ---------------------------------------------------------------------------
-- Paper trading accounts
-- ---------------------------------------------------------------------------
CREATE TABLE accounts (
    id          BIGSERIAL PRIMARY KEY,
    user_id     BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name        VARCHAR(64)  NOT NULL DEFAULT 'Paper',
    currency    VARCHAR(8)   NOT NULL DEFAULT 'USD',
    balance     NUMERIC(18,2) NOT NULL DEFAULT 10000.00,
    equity      NUMERIC(18,2) NOT NULL DEFAULT 10000.00,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, name)
);

-- ---------------------------------------------------------------------------
-- OHLCV candle cache (optional, speeds up indicator recalculation)
-- ---------------------------------------------------------------------------
CREATE TABLE candles (
    id          BIGSERIAL PRIMARY KEY,
    symbol      VARCHAR(32)  NOT NULL,
    timeframe   VARCHAR(8)   NOT NULL,
    open_time   BIGINT       NOT NULL,          -- unix milliseconds
    open        NUMERIC(18,8) NOT NULL,
    high        NUMERIC(18,8) NOT NULL,
    low         NUMERIC(18,8) NOT NULL,
    close       NUMERIC(18,8) NOT NULL,
    volume      NUMERIC(28,8) NOT NULL,
    UNIQUE (symbol, timeframe, open_time)
);

CREATE INDEX idx_candles_lookup ON candles (symbol, timeframe, open_time DESC);

-- ---------------------------------------------------------------------------
-- Generated trading signals
-- ---------------------------------------------------------------------------
CREATE TABLE signals (
    id              BIGSERIAL PRIMARY KEY,
    symbol          VARCHAR(32)   NOT NULL,
    timeframe       VARCHAR(8)    NOT NULL,
    side            VARCHAR(8)    NOT NULL CHECK (side IN ('BUY', 'SELL')),
    strategy        VARCHAR(64)   NOT NULL,
    confidence      NUMERIC(5,2)  NOT NULL CHECK (confidence BETWEEN 0 AND 100),
    price           NUMERIC(18,8) NOT NULL,
    rsi             NUMERIC(8,4),
    macd            NUMERIC(18,8),
    macd_signal     NUMERIC(18,8),
    macd_hist       NUMERIC(18,8),
    sma_fast        NUMERIC(18,8),
    sma_slow        NUMERIC(18,8),
    ema_fast        NUMERIC(18,8),
    ema_slow        NUMERIC(18,8),
    bb_upper        NUMERIC(18,8),
    bb_middle       NUMERIC(18,8),
    bb_lower        NUMERIC(18,8),
    atr             NUMERIC(18,8),
    take_profit     NUMERIC(18,8),
    stop_loss       NUMERIC(18,8),
    reasons_json    TEXT          NOT NULL DEFAULT '[]',
    status          VARCHAR(16)   NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active', 'expired', 'hit_tp', 'hit_sl', 'cancelled')),
    telegram_sent   BOOLEAN       NOT NULL DEFAULT FALSE,
    telegram_message_id VARCHAR(64),
    candle_time     BIGINT,
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_signals_symbol_time ON signals (symbol, created_at DESC);
CREATE INDEX idx_signals_status      ON signals (status, created_at DESC);
CREATE INDEX idx_signals_side        ON signals (side, created_at DESC);

-- Prevent duplicate signals on the same closed candle
CREATE UNIQUE INDEX uq_signals_candle
    ON signals (symbol, timeframe, side, candle_time);

-- ---------------------------------------------------------------------------
-- Paper positions opened from a signal
-- ---------------------------------------------------------------------------
CREATE TABLE positions (
    id            BIGSERIAL PRIMARY KEY,
    account_id    BIGINT        NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    signal_id     BIGINT        REFERENCES signals(id) ON DELETE SET NULL,
    symbol        VARCHAR(32)   NOT NULL,
    side          VARCHAR(8)    NOT NULL CHECK (side IN ('BUY', 'SELL')),
    quantity      NUMERIC(18,8) NOT NULL,
    entry_price   NUMERIC(18,8) NOT NULL,
    current_price NUMERIC(18,8),
    stop_loss     NUMERIC(18,8),
    take_profit   NUMERIC(18,8),
    realized_pnl  NUMERIC(18,2) NOT NULL DEFAULT 0,
    status        VARCHAR(16)   NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open', 'closed')),
    opened_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    closed_at     TIMESTAMPTZ
);

CREATE INDEX idx_positions_open ON positions (account_id, status);

-- ---------------------------------------------------------------------------
-- Telegram delivery log
-- ---------------------------------------------------------------------------
CREATE TABLE telegram_logs (
    id          BIGSERIAL PRIMARY KEY,
    signal_id   BIGINT       REFERENCES signals(id) ON DELETE SET NULL,
    chat_id     VARCHAR(64),
    payload     TEXT,
    status      VARCHAR(16)  NOT NULL DEFAULT 'queued'
                CHECK (status IN ('queued', 'sent', 'failed', 'simulated')),
    error       TEXT,
    sent_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tg_logs_time ON telegram_logs (sent_at DESC);

-- ---------------------------------------------------------------------------
-- Key / value settings (bot token, scan interval, …)
-- ---------------------------------------------------------------------------
CREATE TABLE app_settings (
    key         VARCHAR(64) PRIMARY KEY,
    value       TEXT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Seed demo user + paper account
-- ---------------------------------------------------------------------------
INSERT INTO users (username, email, display_name, language, role)
VALUES ('demo', 'demo@nexa.signal', 'NEXA Desk', 'km', 'trader')
ON CONFLICT (username) DO NOTHING;

INSERT INTO accounts (user_id, name, currency, balance, equity)
SELECT id, 'Paper', 'USD', 10000.00, 10000.00 FROM users WHERE username = 'demo'
ON CONFLICT (user_id, name) DO NOTHING;
