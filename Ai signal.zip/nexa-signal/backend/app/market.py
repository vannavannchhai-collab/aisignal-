from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from .config import SYMBOLS, SYMBOL_BY_ID, TIMEFRAMES

HEADERS = {
    "User-Agent": "NEXA-Signal-Desk/1.0",
    "Accept": "application/json",
}

_cache: dict[str, tuple[float, Any]] = {}
CACHE_TTL = 20.0


def _cached(key: str, ttl: float = CACHE_TTL):
    hit = _cache.get(key)
    if hit and (time.time() - hit[0]) < ttl:
        return hit[1]
    return None


def _store(key: str, value: Any):
    _cache[key] = (time.time(), value)
    return value


def _client() -> httpx.Client:
    return httpx.Client(timeout=12.0, headers=HEADERS, follow_redirects=True)


def _okx_candles(inst: str, bar: str, limit: int = 200) -> list[dict]:
    url = "https://www.okx.com/api/v5/market/candles"
    with _client() as c:
        r = c.get(url, params={"instId": inst, "bar": bar, "limit": str(limit)})
        r.raise_for_status()
        payload = r.json()
    if payload.get("code") != "0":
        raise RuntimeError(payload.get("msg") or "OKX candle error")
    rows = payload.get("data") or []
    candles = []
    for row in rows:
        candles.append(
            {
                "time": int(row[0]),
                "open": float(row[1]),
                "high": float(row[2]),
                "low": float(row[3]),
                "close": float(row[4]),
                "volume": float(row[5]),
            }
        )
    candles.sort(key=lambda x: x["time"])
    return candles


def _coinbase_candles(product: str, granularity: int) -> list[dict]:
    url = f"https://api.exchange.coinbase.com/products/{product}/candles"
    with _client() as c:
        r = c.get(url, params={"granularity": granularity})
        r.raise_for_status()
        rows = r.json()
    candles = []
    for row in rows:
        # [time, low, high, open, close, volume]
        candles.append(
            {
                "time": int(row[0]) * 1000,
                "low": float(row[1]),
                "high": float(row[2]),
                "open": float(row[3]),
                "close": float(row[4]),
                "volume": float(row[5]),
            }
        )
    candles.sort(key=lambda x: x["time"])
    return candles


def _okx_tickers() -> dict[str, dict]:
    key = "okx_tickers"
    hit = _cached(key, 12)
    if hit is not None:
        return hit
    url = "https://www.okx.com/api/v5/market/tickers"
    with _client() as c:
        r = c.get(url, params={"instType": "SPOT"})
        r.raise_for_status()
        payload = r.json()
    by_inst = {}
    for t in payload.get("data") or []:
        by_inst[t["instId"]] = t
    return _store(key, by_inst)


def fetch_candles(symbol_id: str, timeframe: str = "1H", limit: int = 200) -> list[dict]:
    meta = SYMBOL_BY_ID.get(symbol_id)
    if not meta:
        raise KeyError(f"Unknown symbol {symbol_id}")
    tf = TIMEFRAMES.get(timeframe) or TIMEFRAMES["1H"]
    key = f"candles:{symbol_id}:{timeframe}"
    hit = _cached(key, 18)
    if hit is not None:
        return hit

    errors: list[str] = []
    try:
        data = _okx_candles(meta["okx"], tf["okx"], limit=limit)
        if data:
            return _store(key, data)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"okx: {exc}")

    try:
        data = _coinbase_candles(meta["coinbase"], tf["coinbase"])
        if data:
            return _store(key, data[-limit:])
    except Exception as exc:  # noqa: BLE001
        errors.append(f"coinbase: {exc}")

    raise RuntimeError("All market providers failed: " + " | ".join(errors))


def fetch_tickers() -> list[dict[str, Any]]:
    try:
        raw = _okx_tickers()
        out = []
        for s in SYMBOLS:
            t = raw.get(s["okx"])
            if not t:
                continue
            last = float(t["last"])
            open24 = float(t.get("open24h") or last)
            change = ((last - open24) / open24 * 100) if open24 else 0.0
            out.append(
                {
                    "id": s["id"],
                    "base": s["base"],
                    "quote": s["quote"],
                    "name": s["name"],
                    "color": s["color"],
                    "price": last,
                    "open24h": open24,
                    "high24h": float(t.get("high24h") or last),
                    "low24h": float(t.get("low24h") or last),
                    "change24h": change,
                    "volume24h": float(t.get("vol24h") or 0),
                    "volume_ccy": float(t.get("volCcy24h") or 0),
                    "source": "okx",
                }
            )
        if out:
            return out
    except Exception:
        pass

    # Fallback: last close from 1H candles
    out = []
    for s in SYMBOLS:
        try:
            candles = fetch_candles(s["id"], "1H", limit=30)
            if not candles:
                continue
            last = candles[-1]["close"]
            ref = candles[-24]["close"] if len(candles) >= 24 else candles[0]["close"]
            change = ((last - ref) / ref * 100) if ref else 0.0
            out.append(
                {
                    "id": s["id"],
                    "base": s["base"],
                    "quote": s["quote"],
                    "name": s["name"],
                    "color": s["color"],
                    "price": last,
                    "open24h": ref,
                    "high24h": max(c["high"] for c in candles[-24:]),
                    "low24h": min(c["low"] for c in candles[-24:]),
                    "change24h": change,
                    "volume24h": sum(c["volume"] for c in candles[-24:]),
                    "volume_ccy": 0,
                    "source": "candles",
                }
            )
        except Exception:
            continue
    return out


def quotes_map() -> dict[str, float]:
    return {t["id"]: t["price"] for t in fetch_tickers()}
