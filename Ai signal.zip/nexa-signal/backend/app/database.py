from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterator, Optional

from .config import DB_PATH, PAPER_STARTING_BALANCE

_lock = threading.Lock()


def utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def get_db() -> Iterator[sqlite3.Connection]:
    with _lock:
        conn = connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
    ).fetchone()
    return row is not None


def init_db() -> None:
    with get_db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                email TEXT UNIQUE,
                password_hash TEXT,
                display_name TEXT NOT NULL,
                language TEXT NOT NULL DEFAULT 'km',
                timezone TEXT NOT NULL DEFAULT 'Asia/Phnom_Penh',
                telegram_chat_id TEXT,
                telegram_enabled INTEGER NOT NULL DEFAULT 0,
                role TEXT NOT NULL DEFAULT 'trader',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_login_at TEXT
            );

            CREATE TABLE IF NOT EXISTS watchlists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                symbol TEXT NOT NULL,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                UNIQUE (user_id, symbol)
            );

            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                name TEXT NOT NULL DEFAULT 'Paper',
                currency TEXT NOT NULL DEFAULT 'USD',
                balance REAL NOT NULL DEFAULT 10000,
                equity REAL NOT NULL DEFAULT 10000,
                created_at TEXT NOT NULL,
                UNIQUE (user_id, name)
            );

            CREATE TABLE IF NOT EXISTS candles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                open_time INTEGER NOT NULL,
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                volume REAL NOT NULL,
                UNIQUE (symbol, timeframe, open_time)
            );

            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                side TEXT NOT NULL,
                strategy TEXT NOT NULL,
                confidence REAL NOT NULL,
                price REAL NOT NULL,
                rsi REAL,
                macd REAL,
                macd_signal REAL,
                macd_hist REAL,
                sma_fast REAL,
                sma_slow REAL,
                ema_fast REAL,
                ema_slow REAL,
                bb_upper REAL,
                bb_middle REAL,
                bb_lower REAL,
                atr REAL,
                take_profit REAL,
                stop_loss REAL,
                reasons_json TEXT NOT NULL DEFAULT '[]',
                status TEXT NOT NULL DEFAULT 'active',
                telegram_sent INTEGER NOT NULL DEFAULT 0,
                telegram_message_id TEXT,
                candle_time INTEGER,
                created_at TEXT NOT NULL
            );

            CREATE UNIQUE INDEX IF NOT EXISTS uq_signals_candle
                ON signals (symbol, timeframe, side, candle_time);

            CREATE INDEX IF NOT EXISTS idx_signals_created
                ON signals (created_at DESC);

            CREATE TABLE IF NOT EXISTS positions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                signal_id INTEGER REFERENCES signals(id) ON DELETE SET NULL,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                quantity REAL NOT NULL,
                entry_price REAL NOT NULL,
                current_price REAL,
                stop_loss REAL,
                take_profit REAL,
                realized_pnl REAL NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'open',
                opened_at TEXT NOT NULL,
                closed_at TEXT
            );

            CREATE TABLE IF NOT EXISTS telegram_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                signal_id INTEGER REFERENCES signals(id) ON DELETE SET NULL,
                chat_id TEXT,
                payload TEXT,
                status TEXT NOT NULL DEFAULT 'queued',
                error TEXT,
                sent_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT NOT NULL
            );
            """
        )

        now = utcnow()
        existing = conn.execute("SELECT id FROM users WHERE username='demo'").fetchone()
        if not existing:
            cur = conn.execute(
                """
                INSERT INTO users (username, email, display_name, language, timezone,
                                   role, is_active, created_at, updated_at)
                VALUES ('demo', 'demo@nexa.signal', 'NEXA Desk', 'km',
                        'Asia/Phnom_Penh', 'trader', 1, ?, ?)
                """,
                (now, now),
            )
            user_id = cur.lastrowid
            conn.execute(
                """
                INSERT INTO accounts (user_id, name, currency, balance, equity, created_at)
                VALUES (?, 'Paper', 'USD', ?, ?, ?)
                """,
                (user_id, PAPER_STARTING_BALANCE, PAPER_STARTING_BALANCE, now),
            )
        else:
            user_id = existing["id"]
            acc = conn.execute(
                "SELECT id FROM accounts WHERE user_id=?", (user_id,)
            ).fetchone()
            if not acc:
                conn.execute(
                    """
                    INSERT INTO accounts (user_id, name, currency, balance, equity, created_at)
                    VALUES (?, 'Paper', 'USD', ?, ?, ?)
                    """,
                    (user_id, PAPER_STARTING_BALANCE, PAPER_STARTING_BALANCE, now),
                )


def dicts(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    return [dict(r) for r in rows]


def get_setting(key: str, default: str = "") -> str:
    with get_db() as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row and row["value"] is not None else default


def set_setting(key: str, value: str) -> None:
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO app_settings (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
            """,
            (key, value, utcnow()),
        )


def demo_user() -> dict[str, Any]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE username='demo'").fetchone()
        return dict(row) if row else {}


def demo_account() -> dict[str, Any]:
    with get_db() as conn:
        row = conn.execute(
            """
            SELECT a.* FROM accounts a
            JOIN users u ON u.id = a.user_id
            WHERE u.username='demo'
            LIMIT 1
            """
        ).fetchone()
        return dict(row) if row else {}


def insert_signal(payload: dict[str, Any]) -> Optional[int]:
    cols = [
        "symbol", "timeframe", "side", "strategy", "confidence", "price",
        "rsi", "macd", "macd_signal", "macd_hist", "sma_fast", "sma_slow",
        "ema_fast", "ema_slow", "bb_upper", "bb_middle", "bb_lower", "atr",
        "take_profit", "stop_loss", "reasons_json", "status", "telegram_sent",
        "candle_time", "created_at",
    ]
    payload = {**payload, "created_at": payload.get("created_at") or utcnow()}
    placeholders = ",".join("?" for _ in cols)
    sql = f"INSERT OR IGNORE INTO signals ({','.join(cols)}) VALUES ({placeholders})"
    values = [payload.get(c) for c in cols]
    with get_db() as conn:
        cur = conn.execute(sql, values)
        if cur.rowcount == 0:
            return None
        return cur.lastrowid


def list_signals(limit: int = 80, symbol: Optional[str] = None, side: Optional[str] = None) -> list[dict]:
    q = "SELECT * FROM signals WHERE 1=1"
    args: list[Any] = []
    if symbol:
        q += " AND symbol=?"
        args.append(symbol)
    if side:
        q += " AND side=?"
        args.append(side)
    q += " ORDER BY created_at DESC, id DESC LIMIT ?"
    args.append(limit)
    with get_db() as conn:
        return dicts(conn.execute(q, args).fetchall())


def get_signal(signal_id: int) -> Optional[dict]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM signals WHERE id=?", (signal_id,)).fetchone()
        return dict(row) if row else None


def mark_signal_telegram(signal_id: int, sent: bool, message_id: Optional[str] = None) -> None:
    with get_db() as conn:
        conn.execute(
            "UPDATE signals SET telegram_sent=?, telegram_message_id=? WHERE id=?",
            (1 if sent else 0, message_id, signal_id),
        )


def log_telegram(signal_id: Optional[int], chat_id: Optional[str], payload: str, status: str, error: Optional[str] = None) -> int:
    with get_db() as conn:
        cur = conn.execute(
            """
            INSERT INTO telegram_logs (signal_id, chat_id, payload, status, error, sent_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (signal_id, chat_id, payload, status, error, utcnow()),
        )
        return cur.lastrowid


def list_telegram_logs(limit: int = 40) -> list[dict]:
    with get_db() as conn:
        return dicts(
            conn.execute(
                "SELECT * FROM telegram_logs ORDER BY sent_at DESC, id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        )


def list_positions(status: Optional[str] = None) -> list[dict]:
    q = "SELECT * FROM positions"
    args: list[Any] = []
    if status:
        q += " WHERE status=?"
        args.append(status)
    q += " ORDER BY opened_at DESC, id DESC"
    with get_db() as conn:
        return dicts(conn.execute(q, args).fetchall())


def open_position(account_id: int, signal: dict, quantity: float, price: float) -> int:
    with get_db() as conn:
        cur = conn.execute(
            """
            INSERT INTO positions (account_id, signal_id, symbol, side, quantity,
                entry_price, current_price, stop_loss, take_profit, realized_pnl,
                status, opened_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'open', ?)
            """,
            (
                account_id,
                signal.get("id"),
                signal["symbol"],
                signal["side"],
                quantity,
                price,
                price,
                signal.get("stop_loss"),
                signal.get("take_profit"),
                utcnow(),
            ),
        )
        notional = quantity * price
        conn.execute(
            "UPDATE accounts SET balance = balance - ? WHERE id=?",
            (notional, account_id),
        )
        return cur.lastrowid


def update_position_prices(quotes: dict[str, float]) -> None:
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM positions WHERE status='open'").fetchall()
        for row in rows:
            px = quotes.get(row["symbol"])
            if px is None:
                continue
            conn.execute(
                "UPDATE positions SET current_price=? WHERE id=?",
                (px, row["id"]),
            )


def close_position(position_id: int, exit_price: float) -> Optional[dict]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
        if not row or row["status"] != "open":
            return None
        qty = row["quantity"]
        entry = row["entry_price"]
        side = row["side"]
        if side == "BUY":
            pnl = (exit_price - entry) * qty
        else:
            pnl = (entry - exit_price) * qty
        proceeds = qty * exit_price
        # For shorts we credited nothing at open (simplified paper: BUY uses cash).
        if side == "BUY":
            conn.execute(
                "UPDATE accounts SET balance = balance + ? WHERE id=?",
                (proceeds, row["account_id"]),
            )
        else:
            conn.execute(
                "UPDATE accounts SET balance = balance + ? WHERE id=?",
                (qty * entry + pnl, row["account_id"]),
            )
        conn.execute(
            """
            UPDATE positions
            SET status='closed', current_price=?, realized_pnl=?, closed_at=?
            WHERE id=?
            """,
            (exit_price, pnl, utcnow(), position_id),
        )
        return {**dict(row), "realized_pnl": pnl, "status": "closed"}


def reset_paper() -> None:
    with get_db() as conn:
        acc = conn.execute(
            """
            SELECT a.id FROM accounts a
            JOIN users u ON u.id=a.user_id WHERE u.username='demo'
            """
        ).fetchone()
        if not acc:
            return
        conn.execute("DELETE FROM positions WHERE account_id=?", (acc["id"],))
        conn.execute(
            "UPDATE accounts SET balance=?, equity=? WHERE id=?",
            (PAPER_STARTING_BALANCE, PAPER_STARTING_BALANCE, acc["id"]),
        )


def stats_overview() -> dict[str, Any]:
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) AS c FROM signals").fetchone()["c"]
        buys = conn.execute("SELECT COUNT(*) AS c FROM signals WHERE side='BUY'").fetchone()["c"]
        sells = conn.execute("SELECT COUNT(*) AS c FROM signals WHERE side='SELL'").fetchone()["c"]
        today = conn.execute(
            "SELECT COUNT(*) AS c FROM signals WHERE created_at >= date('now')"
        ).fetchone()["c"]
        closed = conn.execute(
            "SELECT COUNT(*) AS c, COALESCE(SUM(realized_pnl),0) AS pnl FROM positions WHERE status='closed'"
        ).fetchone()
        wins = conn.execute(
            "SELECT COUNT(*) AS c FROM positions WHERE status='closed' AND realized_pnl>0"
        ).fetchone()["c"]
        closed_n = closed["c"] or 0
        return {
            "signals_total": total,
            "signals_buy": buys,
            "signals_sell": sells,
            "signals_today": today,
            "closed_trades": closed_n,
            "realized_pnl": closed["pnl"] or 0,
            "win_rate": (wins / closed_n * 100) if closed_n else 0,
        }
