from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

DB_PATH = Path(os.getenv("NEXA_DB_PATH", DATA_DIR / "nexa.db"))

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

SCAN_INTERVAL_SEC = int(os.getenv("NEXA_SCAN_INTERVAL", "60"))
DEFAULT_TIMEFRAME = os.getenv("NEXA_TIMEFRAME", "1H")
PAPER_STARTING_BALANCE = float(os.getenv("NEXA_PAPER_BALANCE", "10000"))

SYMBOLS = [
    {"id": "BTC-USD", "base": "BTC", "quote": "USD", "okx": "BTC-USDT", "coinbase": "BTC-USD", "name": "Bitcoin", "color": "#f7931a"},
    {"id": "ETH-USD", "base": "ETH", "quote": "USD", "okx": "ETH-USDT", "coinbase": "ETH-USD", "name": "Ethereum", "color": "#627eea"},
    {"id": "SOL-USD", "base": "SOL", "quote": "USD", "okx": "SOL-USDT", "coinbase": "SOL-USD", "name": "Solana", "color": "#9945ff"},
    {"id": "XRP-USD", "base": "XRP", "quote": "USD", "okx": "XRP-USDT", "coinbase": "XRP-USD", "name": "XRP", "color": "#23292f"},
    {"id": "DOGE-USD", "base": "DOGE", "quote": "USD", "okx": "DOGE-USDT", "coinbase": "DOGE-USD", "name": "Dogecoin", "color": "#c2a633"},
    {"id": "ADA-USD", "base": "ADA", "quote": "USD", "okx": "ADA-USDT", "coinbase": "ADA-USD", "name": "Cardano", "color": "#0033ad"},
    {"id": "AVAX-USD", "base": "AVAX", "quote": "USD", "okx": "AVAX-USDT", "coinbase": "AVAX-USD", "name": "Avalanche", "color": "#e84142"},
    {"id": "LINK-USD", "base": "LINK", "quote": "USD", "okx": "LINK-USDT", "coinbase": "LINK-USD", "name": "Chainlink", "color": "#2a5ada"},
    {"id": "LTC-USD", "base": "LTC", "quote": "USD", "okx": "LTC-USDT", "coinbase": "LTC-USD", "name": "Litecoin", "color": "#345d9d"},
    {"id": "DOT-USD", "base": "DOT", "quote": "USD", "okx": "DOT-USDT", "coinbase": "DOT-USD", "name": "Polkadot", "color": "#e6007a"},
]

TIMEFRAMES = {
    "15m": {"okx": "15m", "coinbase": 900, "label": "15m"},
    "1H": {"okx": "1H", "coinbase": 3600, "label": "1H"},
    "4H": {"okx": "4H", "coinbase": 21600, "label": "4H"},
    "1D": {"okx": "1D", "coinbase": 86400, "label": "1D"},
}

SYMBOL_BY_ID = {s["id"]: s for s in SYMBOLS}
