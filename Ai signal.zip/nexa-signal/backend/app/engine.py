from __future__ import annotations

import json
from typing import Any, Optional

from . import database as db
from .config import SYMBOLS
from .indicators import compute_all
from .market import fetch_candles, quotes_map
from . import telegram_bot


def _round_px(price: float) -> float:
    if price >= 1000:
        return round(price, 2)
    if price >= 1:
        return round(price, 4)
    return round(price, 6)


def evaluate(symbol: str, timeframe: str, candles: list[dict]) -> Optional[dict[str, Any]]:
    if len(candles) < 60:
        return None
    computed = compute_all(candles)
    s = computed["snapshot"]
    close = s["close"]
    if close is None or s["rsi"] is None or s["macd_hist"] is None:
        return None

    rsi = s["rsi"]
    rsi_prev = s["rsi_prev"] if s["rsi_prev"] is not None else rsi
    hist = s["macd_hist"]
    hist_prev = s["macd_hist_prev"] if s["macd_hist_prev"] is not None else hist
    macd_v = s["macd"]
    macd_sig = s["macd_signal"]
    ema20, ema50 = s["ema20"], s["ema50"]
    sma20, sma50 = s["sma20"], s["sma50"]
    bb_u, bb_l = s["bb_upper"], s["bb_lower"]
    atr = s["atr"] or close * 0.012

    buy_score = 0
    sell_score = 0
    buy_en: list[str] = []
    buy_km: list[str] = []
    sell_en: list[str] = []
    sell_km: list[str] = []

    # RSI
    if rsi < 30:
        buy_score += 28
        buy_en.append(f"RSI oversold ({rsi:.1f})")
        buy_km.append(f"RSI លក់លើស ({rsi:.1f})")
    elif rsi < 40:
        buy_score += 12
        buy_en.append(f"RSI recovering ({rsi:.1f})")
        buy_km.append(f"RSI កំពុងងើប ({rsi:.1f})")
    if rsi > 70:
        sell_score += 28
        sell_en.append(f"RSI overbought ({rsi:.1f})")
        sell_km.append(f"RSI ទិញលើស ({rsi:.1f})")
    elif rsi > 60:
        sell_score += 12
        sell_en.append(f"RSI stretched ({rsi:.1f})")
        sell_km.append(f"RSI តានតឹង ({rsi:.1f})")
    if rsi_prev < 50 <= rsi:
        buy_score += 10
        buy_en.append("RSI crossed above 50")
        buy_km.append("RSI ឆ្លងលើស 50")
    if rsi_prev > 50 >= rsi:
        sell_score += 10
        sell_en.append("RSI crossed below 50")
        sell_km.append("RSI ឆ្លងក្រោម 50")

    # MACD — histogram sign flip is the crossover
    if hist_prev is not None and hist is not None:
        if hist_prev <= 0 < hist:
            buy_score += 24
            buy_en.append("MACD bullish crossover")
            buy_km.append("MACD ផ្លាស់ប្តូរឡើង")
        elif hist_prev >= 0 > hist:
            sell_score += 24
            sell_en.append("MACD bearish crossover")
            sell_km.append("MACD ផ្លាស់ប្តូរចុះ")
        elif hist > 0 and hist > hist_prev:
            buy_score += 10
            buy_en.append("MACD histogram expanding up")
            buy_km.append("MACD histogram កំពុងពង្រីកឡើង")
        elif hist < 0 and hist < hist_prev:
            sell_score += 10
            sell_en.append("MACD histogram expanding down")
            sell_km.append("MACD histogram កំពុងពង្រីកចុះ")

    # Trend filter EMA / SMA
    if ema20 is not None and ema50 is not None:
        if ema20 > ema50:
            buy_score += 12
            buy_en.append("EMA20 above EMA50 (uptrend)")
            buy_km.append("EMA20 លើស EMA50 (និន្នាការឡើង)")
            if close > ema20:
                buy_score += 10
                buy_en.append("Price holding above EMA20")
                buy_km.append("តម្លៃនៅលើ EMA20")
        else:
            sell_score += 12
            sell_en.append("EMA20 below EMA50 (downtrend)")
            sell_km.append("EMA20 ក្រោម EMA50 (និន្នាការចុះ)")
            if close < ema20:
                sell_score += 10
                sell_en.append("Price holding below EMA20")
                sell_km.append("តម្លៃនៅក្រោម EMA20")

    if sma50 is not None:
        if close > sma50:
            buy_score += 8
            buy_en.append("Price above SMA50")
            buy_km.append("តម្លៃលើស SMA50")
        else:
            sell_score += 8
            sell_en.append("Price below SMA50")
            sell_km.append("តម្លៃក្រោម SMA50")

    # Bollinger bounce / stretch
    if bb_l is not None and close <= bb_l * 1.004:
        buy_score += 16
        buy_en.append("Price at lower Bollinger band")
        buy_km.append("តម្លៃនៅ Bollinger ផ្នែកក្រោម")
    if bb_u is not None and close >= bb_u * 0.996:
        sell_score += 16
        sell_en.append("Price at upper Bollinger band")
        sell_km.append("តម្លៃនៅ Bollinger ផ្នែកលើ")

    # Need at least two confirming reasons and a meaningful score
    buy_reasons = list(zip(buy_en, buy_km))
    sell_reasons = list(zip(sell_en, sell_km))

    side = None
    score = 0
    reasons: list[dict[str, str]] = []
    if buy_score >= sell_score and buy_score >= 30 and len(buy_reasons) >= 2:
        side = "BUY"
        score = buy_score
        reasons = [{"en": a, "km": b} for a, b in buy_reasons]
    elif sell_score > buy_score and sell_score >= 30 and len(sell_reasons) >= 2:
        side = "SELL"
        score = sell_score
        reasons = [{"en": a, "km": b} for a, b in sell_reasons]
    else:
        return {
            "signal": None,
            "snapshot": s,
            "scores": {"buy": buy_score, "sell": sell_score},
            "series": computed["series"],
        }

    confidence = max(52.0, min(96.0, 50 + (score - 30) * 0.75 + len(reasons) * 2.5))
    if side == "BUY":
        take_profit = close + 2.0 * atr
        stop_loss = close - 1.2 * atr
        strategy = "Momentum Reversal" if rsi < 40 else "Trend Continuation"
        strategy_km = "បញ្ច្រាសសន្ទុះ" if rsi < 40 else "បន្តនិន្នាការ"
    else:
        take_profit = close - 2.0 * atr
        stop_loss = close + 1.2 * atr
        strategy = "Distribution Fade" if rsi > 60 else "Trend Continuation"
        strategy_km = "លក់ចែកចាយ" if rsi > 60 else "បន្តនិន្នាការ"

    candle_time = candles[-1]["time"]
    payload = {
        "symbol": symbol,
        "timeframe": timeframe,
        "side": side,
        "strategy": strategy,
        "strategy_km": strategy_km,
        "confidence": round(confidence, 1),
        "price": _round_px(close),
        "rsi": round(rsi, 2),
        "macd": macd_v,
        "macd_signal": macd_sig,
        "macd_hist": hist,
        "sma_fast": sma20,
        "sma_slow": sma50,
        "ema_fast": ema20,
        "ema_slow": ema50,
        "bb_upper": bb_u,
        "bb_middle": s["bb_middle"],
        "bb_lower": bb_l,
        "atr": atr,
        "take_profit": _round_px(take_profit),
        "stop_loss": _round_px(stop_loss),
        "reasons_json": json.dumps(reasons, ensure_ascii=False),
        "status": "active",
        "telegram_sent": 0,
        "candle_time": candle_time,
    }
    return {
        "signal": payload,
        "snapshot": s,
        "scores": {"buy": buy_score, "sell": sell_score},
        "series": computed["series"],
    }


def analyze_symbol(symbol: str, timeframe: str = "1H") -> dict[str, Any]:
    candles = fetch_candles(symbol, timeframe)
    result = evaluate(symbol, timeframe, candles) or {
        "signal": None,
        "snapshot": {},
        "scores": {"buy": 0, "sell": 0},
        "series": {},
    }
    # slim series for chart overlays (last 180)
    slim = []
    series = result.get("series") or {}
    start = max(0, len(candles) - 180)
    for i, c in enumerate(candles[start:], start=start):
        slim.append(
            {
                "time": int(c["time"] / 1000),
                "open": c["open"],
                "high": c["high"],
                "low": c["low"],
                "close": c["close"],
                "volume": c["volume"],
                "sma20": series.get("sma20", [None] * len(candles))[i] if series else None,
                "sma50": series.get("sma50", [None] * len(candles))[i] if series else None,
                "ema20": series.get("ema20", [None] * len(candles))[i] if series else None,
                "bb_upper": series.get("bb_upper", [None] * len(candles))[i] if series else None,
                "bb_lower": series.get("bb_lower", [None] * len(candles))[i] if series else None,
                "rsi": series.get("rsi", [None] * len(candles))[i] if series else None,
                "macd": series.get("macd", [None] * len(candles))[i] if series else None,
                "macd_signal": series.get("macd_signal", [None] * len(candles))[i] if series else None,
                "macd_hist": series.get("macd_hist", [None] * len(candles))[i] if series else None,
            }
        )
    snap = result["snapshot"]
    bias = "NEUTRAL"
    buy_s = result["scores"]["buy"]
    sell_s = result["scores"]["sell"]
    if buy_s - sell_s >= 12:
        bias = "BULLISH"
    elif sell_s - buy_s >= 12:
        bias = "BEARISH"
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "candles": slim,
        "snapshot": snap,
        "scores": result["scores"],
        "bias": bias,
        "pending_signal": result["signal"],
    }


def persist_and_notify(signal: dict[str, Any]) -> Optional[dict[str, Any]]:
    sid = db.insert_signal(signal)
    if sid is None:
        return None
    stored = db.get_signal(sid)
    if stored:
        telegram_bot.dispatch_signal(stored)
    return stored


def scan_all_timeframes(notify: bool = True) -> list[dict[str, Any]]:
    created: list[dict[str, Any]] = []
    for tf in ("15m", "1H", "4H"):
        created.extend(scan_markets(tf, notify=notify))
    return created


def scan_markets(timeframe: str = "1H", notify: bool = True) -> list[dict[str, Any]]:
    created: list[dict[str, Any]] = []
    for meta in SYMBOLS:
        try:
            candles = fetch_candles(meta["id"], timeframe)
            result = evaluate(meta["id"], timeframe, candles)
            if not result or not result.get("signal"):
                continue
            sig = result["signal"]
            if notify:
                stored = persist_and_notify(sig)
                if stored:
                    created.append(stored)
            else:
                created.append(sig)
        except Exception:
            continue
    return created


def mark_to_market() -> None:
    quotes = quotes_map()
    if quotes:
        db.update_position_prices(quotes)
    # Auto-close on TP / SL
    for pos in db.list_positions(status="open"):
        px = pos.get("current_price")
        if px is None:
            continue
        sl, tp = pos.get("stop_loss"), pos.get("take_profit")
        side = pos["side"]
        hit = False
        if side == "BUY":
            if sl and px <= sl:
                hit = True
            if tp and px >= tp:
                hit = True
        else:
            if sl and px >= sl:
                hit = True
            if tp and px <= tp:
                hit = True
        if hit:
            db.close_position(pos["id"], px)


def portfolio_view() -> dict[str, Any]:
    mark_to_market()
    acc = db.demo_account()
    positions = db.list_positions()
    open_pos = [p for p in positions if p["status"] == "open"]
    closed = [p for p in positions if p["status"] == "closed"]
    unreal = 0.0
    for p in open_pos:
        px = p.get("current_price") or p["entry_price"]
        if p["side"] == "BUY":
            unreal += (px - p["entry_price"]) * p["quantity"]
        else:
            unreal += (p["entry_price"] - px) * p["quantity"]
    used = sum((p.get("current_price") or p["entry_price"]) * p["quantity"] for p in open_pos)
    cash = acc.get("balance") or 0
    equity = cash + used + (unreal if False else 0)
    # For longs, cash was reduced by notional at open; used ≈ current value.
    # Equity = cash + current market value of longs.
    long_value = 0.0
    for p in open_pos:
        px = p.get("current_price") or p["entry_price"]
        if p["side"] == "BUY":
            long_value += px * p["quantity"]
        else:
            # short mark: leftover from simplified model
            long_value += (2 * p["entry_price"] - px) * p["quantity"]
    equity = cash + long_value
    realized = sum(p.get("realized_pnl") or 0 for p in closed)
    return {
        "account": {**acc, "equity": round(equity, 2), "unrealized_pnl": round(unreal, 2)},
        "open": open_pos,
        "closed": closed[:20],
        "realized_pnl": round(realized, 2),
        "unrealized_pnl": round(unreal, 2),
        "equity": round(equity, 2),
        "cash": round(cash, 2),
    }
