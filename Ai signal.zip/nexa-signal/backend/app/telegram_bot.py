from __future__ import annotations

import json
from typing import Any, Optional

import httpx

from . import database as db
from .config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID


def _cfg() -> tuple[str, str]:
    token = db.get_setting("telegram_bot_token", TELEGRAM_BOT_TOKEN) or TELEGRAM_BOT_TOKEN
    chat = db.get_setting("telegram_chat_id", TELEGRAM_CHAT_ID) or TELEGRAM_CHAT_ID
    return token.strip(), chat.strip()


def status() -> dict[str, Any]:
    token, chat = _cfg()
    return {
        "configured": bool(token and chat),
        "has_token": bool(token),
        "chat_id": chat if chat else None,
        "mode": "live" if (token and chat) else "simulated",
    }


def format_signal_html(signal: dict[str, Any], lang: str = "km") -> str:
    side = signal.get("side") or "BUY"
    is_buy = side == "BUY"
    arrow = "🟢 ទិញ" if is_buy else "🔴 លក់"
    if lang != "km":
        arrow = "🟢 BUY" if is_buy else "🔴 SELL"
    reasons = []
    try:
        raw = signal.get("reasons_json") or "[]"
        parsed = json.loads(raw) if isinstance(raw, str) else raw
        for r in parsed:
            reasons.append(r.get(lang) or r.get("en") or "")
    except Exception:
        pass
    reason_html = "".join(f"• {r}\n" for r in reasons[:5] if r)
    px = signal.get("price")
    tp = signal.get("take_profit")
    sl = signal.get("stop_loss")
    conf = signal.get("confidence")
    rsi = signal.get("rsi")
    title = "NEXA Signal Desk"
    if lang == "km":
        body = (
            f"<b>{title}</b>\n"
            f"{arrow}  <b>{signal.get('symbol')}</b>  ·  {signal.get('timeframe')}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"តម្លៃ៖  <code>{px}</code>\n"
            f"ទំនុកចិត្ត៖  <b>{conf}%</b>\n"
            f"RSI៖  {rsi}\n"
            f"យុទ្ធសាស្ត្រ៖  {signal.get('strategy')}\n"
            f"\n{reason_html}"
            f"\n🎯 TP  <code>{tp}</code>\n"
            f"🛡 SL  <code>{sl}</code>\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"<i>សម្រាប់គោលបំណងអប់រំ — មិនមែនដំបូន្មានហិរញ្ញវត្ថុ</i>"
        )
    else:
        body = (
            f"<b>{title}</b>\n"
            f"{arrow}  <b>{signal.get('symbol')}</b>  ·  {signal.get('timeframe')}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"Price:  <code>{px}</code>\n"
            f"Confidence:  <b>{conf}%</b>\n"
            f"RSI:  {rsi}\n"
            f"Strategy:  {signal.get('strategy')}\n"
            f"\n{reason_html}"
            f"\n🎯 TP  <code>{tp}</code>\n"
            f"🛡 SL  <code>{sl}</code>\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"<i>Educational use only — not financial advice</i>"
        )
    return body


def _send_telegram(token: str, chat_id: str, html: str) -> dict[str, Any]:
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    with httpx.Client(timeout=15.0) as client:
        r = client.post(
            url,
            json={
                "chat_id": chat_id,
                "text": html,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            },
        )
        data = r.json()
        if not data.get("ok"):
            raise RuntimeError(data.get("description") or "Telegram API error")
        return data


def dispatch_signal(signal: dict[str, Any], lang: str = "km") -> dict[str, Any]:
    html = format_signal_html(signal, lang=lang)
    token, chat = _cfg()
    sid = signal.get("id")
    if not token or not chat:
        db.log_telegram(sid, chat or None, html, "simulated", None)
        return {"ok": True, "mode": "simulated", "html": html}
    try:
        resp = _send_telegram(token, chat, html)
        mid = str(resp.get("result", {}).get("message_id") or "")
        db.log_telegram(sid, chat, html, "sent", None)
        if sid:
            db.mark_signal_telegram(sid, True, mid)
        return {"ok": True, "mode": "live", "message_id": mid, "html": html}
    except Exception as exc:  # noqa: BLE001
        db.log_telegram(sid, chat, html, "failed", str(exc))
        return {"ok": False, "mode": "live", "error": str(exc), "html": html}


def send_test(lang: str = "km") -> dict[str, Any]:
    token, chat = _cfg()
    if lang == "km":
        text = (
            "<b>NEXA Signal Desk</b>\n"
            "ភ្ជាប់ Telegram ជោគជ័យ។ សញ្ញាទិញ/លក់នឹងមកដល់ទីនេះដោយស្វ័យប្រវត្តិ។"
        )
    else:
        text = (
            "<b>NEXA Signal Desk</b>\n"
            "Telegram connected. Buy/sell signals will be delivered here automatically."
        )
    if not token or not chat:
        db.log_telegram(None, chat or None, text, "simulated", None)
        return {"ok": True, "mode": "simulated", "html": text}
    try:
        resp = _send_telegram(token, chat, text)
        db.log_telegram(None, chat, text, "sent", None)
        return {"ok": True, "mode": "live", "message_id": resp.get("result", {}).get("message_id")}
    except Exception as exc:  # noqa: BLE001
        db.log_telegram(None, chat, text, "failed", str(exc))
        return {"ok": False, "error": str(exc)}


def save_config(token: Optional[str], chat_id: Optional[str]) -> dict[str, Any]:
    if token is not None:
        db.set_setting("telegram_bot_token", token.strip())
    if chat_id is not None:
        db.set_setting("telegram_chat_id", chat_id.strip())
    return status()
