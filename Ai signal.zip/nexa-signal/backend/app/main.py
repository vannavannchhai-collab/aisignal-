from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from . import database as db
from . import engine
from . import telegram_bot
from .config import SCAN_INTERVAL_SEC, SYMBOLS, TIMEFRAMES
from .indicators import compute_all
from .market import fetch_candles, fetch_tickers, quotes_map

STATE = {
    "started_at": None,
    "last_scan_at": None,
    "last_scan_count": 0,
    "last_error": None,
    "scanning": False,
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    STATE["started_at"] = datetime.now(timezone.utc).isoformat()

    async def loop():
        await asyncio.sleep(2)
        while True:
            try:
                STATE["scanning"] = True
                created = await asyncio.to_thread(engine.scan_all_timeframes)
                await asyncio.to_thread(engine.mark_to_market)
                STATE["last_scan_at"] = datetime.now(timezone.utc).isoformat()
                STATE["last_scan_count"] = len(created)
                STATE["last_error"] = None
            except Exception as exc:  # noqa: BLE001
                STATE["last_error"] = str(exc)
            finally:
                STATE["scanning"] = False
            await asyncio.sleep(SCAN_INTERVAL_SEC)

    task = asyncio.create_task(loop())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


app = FastAPI(
    title="NEXA Signal Desk",
    version="1.0.0",
    description="Live-market technical signals, paper desk, and Telegram dispatch.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class TelegramConfigIn(BaseModel):
    token: Optional[str] = None
    chat_id: Optional[str] = None


class TradeIn(BaseModel):
    signal_id: int
    notional_usd: float = 1000


class CloseIn(BaseModel):
    position_id: int


@app.get("/api/health")
def health():
    phnom = datetime.now(ZoneInfo("Asia/Phnom_Penh"))
    return {
        "ok": True,
        "service": "nexa-signal",
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "time_phnom_penh": phnom.isoformat(),
        "started_at": STATE["started_at"],
        "last_scan_at": STATE["last_scan_at"],
        "last_scan_count": STATE["last_scan_count"],
        "scanning": STATE["scanning"],
        "last_error": STATE["last_error"],
        "scan_interval_sec": SCAN_INTERVAL_SEC,
        "telegram": telegram_bot.status(),
    }


@app.get("/api/symbols")
def symbols():
    return {"symbols": SYMBOLS, "timeframes": list(TIMEFRAMES.keys())}


@app.get("/api/markets")
def markets():
    tickers = fetch_tickers()
    latest = {}
    for s in db.list_signals(limit=200):
        if s["symbol"] not in latest:
            latest[s["symbol"]] = s
    for t in tickers:
        t["last_signal"] = latest.get(t["id"])
        try:
            candles = fetch_candles(t["id"], "1H", limit=80)
            snap = compute_all(candles)["snapshot"] if len(candles) >= 30 else {}
            t["rsi"] = snap.get("rsi")
            t["macd_hist"] = snap.get("macd_hist")
            t["ema20"] = snap.get("ema20")
            t["ema50"] = snap.get("ema50")
        except Exception as exc:  # noqa: BLE001
            t["rsi"] = None
            t["indicator_error"] = str(exc)
    return {"markets": tickers}


@app.get("/api/markets/{symbol}/analysis")
def analysis(symbol: str, tf: str = Query("1H")):
    symbol = symbol.upper()
    if symbol not in {s["id"] for s in SYMBOLS}:
        raise HTTPException(404, "Unknown symbol")
    if tf not in TIMEFRAMES:
        tf = "1H"
    try:
        data = engine.analyze_symbol(symbol, tf)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(502, f"Market data error: {exc}") from exc
    return data


@app.get("/api/signals")
def signals(
    limit: int = Query(80, ge=1, le=300),
    symbol: Optional[str] = None,
    side: Optional[str] = None,
):
    rows = db.list_signals(limit=limit, symbol=symbol, side=side)
    return {"signals": rows}


@app.post("/api/signals/scan")
def scan(tf: str = Query("all")):
    if tf == "all":
        created = engine.scan_all_timeframes(notify=True)
    else:
        if tf not in TIMEFRAMES:
            tf = "1H"
        created = engine.scan_markets(tf, notify=True)
    STATE["last_scan_at"] = datetime.now(timezone.utc).isoformat()
    STATE["last_scan_count"] = len(created)
    return {"created": created, "count": len(created)}


@app.get("/api/portfolio")
def portfolio():
    return engine.portfolio_view()


@app.post("/api/portfolio/trade")
def take_trade(body: TradeIn):
    sig = db.get_signal(body.signal_id)
    if not sig:
        raise HTTPException(404, "Signal not found")
    acc = db.demo_account()
    quotes = quotes_map()
    price = quotes.get(sig["symbol"]) or sig["price"]
    notional = max(50.0, min(body.notional_usd, acc["balance"] * 0.95 if acc["balance"] > 50 else 0))
    if notional <= 0:
        raise HTTPException(400, "Insufficient cash")
    qty = notional / price
    pid = db.open_position(acc["id"], {**sig, "id": sig["id"]}, qty, price)
    return {"ok": True, "position_id": pid, "quantity": qty, "price": price}


@app.post("/api/portfolio/close")
def close_trade(body: CloseIn):
    positions = {p["id"]: p for p in db.list_positions()}
    pos = positions.get(body.position_id)
    if not pos:
        raise HTTPException(404, "Position not found")
    quotes = quotes_map()
    px = quotes.get(pos["symbol"]) or pos.get("current_price") or pos["entry_price"]
    closed = db.close_position(body.position_id, px)
    return {"ok": True, "position": closed}


@app.post("/api/portfolio/reset")
def reset_paper():
    db.reset_paper()
    return engine.portfolio_view()


@app.get("/api/stats")
def stats():
    return {"stats": db.stats_overview(), "runtime": STATE}


@app.get("/api/telegram/status")
def tg_status():
    return telegram_bot.status()


@app.post("/api/telegram/config")
def tg_config(body: TelegramConfigIn):
    return telegram_bot.save_config(body.token, body.chat_id)


@app.post("/api/telegram/test")
def tg_test(lang: str = "km"):
    return telegram_bot.send_test(lang=lang)


@app.post("/api/telegram/resend/{signal_id}")
def tg_resend(signal_id: int, lang: str = "km"):
    sig = db.get_signal(signal_id)
    if not sig:
        raise HTTPException(404, "Signal not found")
    return telegram_bot.dispatch_signal(sig, lang=lang)


@app.get("/api/telegram/logs")
def tg_logs(limit: int = 40):
    return {"logs": db.list_telegram_logs(limit=limit)}


@app.get("/api/schema")
def schema():
    path = Path(__file__).resolve().parents[1] / "schema.sql"
    sql = path.read_text(encoding="utf-8") if path.exists() else ""
    return {
        "engine": "PostgreSQL (production) / SQLite (demo)",
        "tables": [
            {"name": "users", "role": "Traders, language, Telegram chat id"},
            {"name": "watchlists", "role": "Per-user symbol lists"},
            {"name": "accounts", "role": "Paper balances"},
            {"name": "candles", "role": "OHLCV cache"},
            {"name": "signals", "role": "Generated BUY/SELL with indicators"},
            {"name": "positions", "role": "Paper trades linked to signals"},
            {"name": "telegram_logs", "role": "Delivery audit trail"},
            {"name": "app_settings", "role": "Bot token and runtime flags"},
        ],
        "sql": sql,
    }
