from __future__ import annotations

from typing import Iterable, Optional


def _as_list(values: Iterable[float]) -> list[float]:
    return [float(v) for v in values]


def sma(values: Iterable[float], period: int) -> list[Optional[float]]:
    data = _as_list(values)
    out: list[Optional[float]] = [None] * len(data)
    if period <= 0 or len(data) < period:
        return out
    window = 0.0
    for i, v in enumerate(data):
        window += v
        if i >= period:
            window -= data[i - period]
        if i >= period - 1:
            out[i] = window / period
    return out


def ema(values: Iterable[float], period: int) -> list[Optional[float]]:
    data = _as_list(values)
    out: list[Optional[float]] = [None] * len(data)
    if period <= 0 or len(data) < period:
        return out
    k = 2.0 / (period + 1)
    seed = sum(data[:period]) / period
    out[period - 1] = seed
    prev = seed
    for i in range(period, len(data)):
        prev = data[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def rsi(values: Iterable[float], period: int = 14) -> list[Optional[float]]:
    data = _as_list(values)
    n = len(data)
    out: list[Optional[float]] = [None] * n
    if n < period + 1:
        return out
    gains = 0.0
    losses = 0.0
    for i in range(1, period + 1):
        delta = data[i] - data[i - 1]
        if delta >= 0:
            gains += delta
        else:
            losses -= delta
    avg_gain = gains / period
    avg_loss = losses / period
    if avg_loss == 0:
        out[period] = 100.0
    else:
        out[period] = 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)
    for i in range(period + 1, n):
        delta = data[i] - data[i - 1]
        gain = delta if delta > 0 else 0.0
        loss = -delta if delta < 0 else 0.0
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
        if avg_loss == 0:
            out[i] = 100.0
        else:
            out[i] = 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)
    return out


def macd(
    values: Iterable[float],
    fast: int = 12,
    slow: int = 26,
    signal_period: int = 9,
) -> tuple[list[Optional[float]], list[Optional[float]], list[Optional[float]]]:
    data = _as_list(values)
    n = len(data)
    fast_ema = ema(data, fast)
    slow_ema = ema(data, slow)
    line: list[Optional[float]] = [None] * n
    for i in range(n):
        if fast_ema[i] is not None and slow_ema[i] is not None:
            line[i] = fast_ema[i] - slow_ema[i]
    # EMA of MACD line — skip leading Nones
    compact = [(i, v) for i, v in enumerate(line) if v is not None]
    signal: list[Optional[float]] = [None] * n
    hist: list[Optional[float]] = [None] * n
    if len(compact) >= signal_period:
        series = [v for _, v in compact]
        sig_series = ema(series, signal_period)
        for (idx, _), s in zip(compact, sig_series):
            signal[idx] = s
            if s is not None and line[idx] is not None:
                hist[idx] = line[idx] - s
    return line, signal, hist


def bollinger(
    values: Iterable[float], period: int = 20, num_std: float = 2.0
) -> tuple[list[Optional[float]], list[Optional[float]], list[Optional[float]]]:
    data = _as_list(values)
    n = len(data)
    mid = sma(data, period)
    upper: list[Optional[float]] = [None] * n
    lower: list[Optional[float]] = [None] * n
    for i in range(period - 1, n):
        window = data[i - period + 1 : i + 1]
        mean = mid[i]
        if mean is None:
            continue
        var = sum((x - mean) ** 2 for x in window) / period
        std = var ** 0.5
        upper[i] = mean + num_std * std
        lower[i] = mean - num_std * std
    return upper, mid, lower


def atr(
    highs: Iterable[float],
    lows: Iterable[float],
    closes: Iterable[float],
    period: int = 14,
) -> list[Optional[float]]:
    h = _as_list(highs)
    l = _as_list(lows)
    c = _as_list(closes)
    n = len(c)
    out: list[Optional[float]] = [None] * n
    if n < period + 1:
        return out
    trs: list[float] = [0.0] * n
    trs[0] = h[0] - l[0]
    for i in range(1, n):
        trs[i] = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
    seed = sum(trs[1 : period + 1]) / period
    out[period] = seed
    prev = seed
    for i in range(period + 1, n):
        prev = (prev * (period - 1) + trs[i]) / period
        out[i] = prev
    return out


def last(series: list[Optional[float]]) -> Optional[float]:
    for v in reversed(series):
        if v is not None:
            return v
    return None


def nth_last(series: list[Optional[float]], n: int = 2) -> Optional[float]:
    found = 0
    for v in reversed(series):
        if v is not None:
            found += 1
            if found == n:
                return v
    return None


def crossed_up(prev_a: Optional[float], a: Optional[float], prev_b: Optional[float], b: Optional[float]) -> bool:
    if None in (prev_a, a, prev_b, b):
        return False
    return prev_a <= prev_b and a > b


def crossed_down(prev_a: Optional[float], a: Optional[float], prev_b: Optional[float], b: Optional[float]) -> bool:
    if None in (prev_a, a, prev_b, b):
        return False
    return prev_a >= prev_b and a < b


def compute_all(candles: list[dict]) -> dict:
    """Return indicator series plus the latest snapshot for a candle list.

    Each candle: {time, open, high, low, close, volume}
    """
    closes = [c["close"] for c in candles]
    highs = [c["high"] for c in candles]
    lows = [c["low"] for c in candles]

    rsi_v = rsi(closes, 14)
    macd_line, macd_sig, macd_hist = macd(closes)
    sma20 = sma(closes, 20)
    sma50 = sma(closes, 50)
    ema12 = ema(closes, 12)
    ema26 = ema(closes, 26)
    ema20 = ema(closes, 20)
    ema50 = ema(closes, 50)
    bb_u, bb_m, bb_l = bollinger(closes, 20, 2.0)
    atr_v = atr(highs, lows, closes, 14)

    snap = {
        "rsi": last(rsi_v),
        "rsi_prev": nth_last(rsi_v, 2),
        "macd": last(macd_line),
        "macd_signal": last(macd_sig),
        "macd_hist": last(macd_hist),
        "macd_hist_prev": nth_last(macd_hist, 2),
        "sma20": last(sma20),
        "sma50": last(sma50),
        "ema12": last(ema12),
        "ema26": last(ema26),
        "ema20": last(ema20),
        "ema50": last(ema50),
        "bb_upper": last(bb_u),
        "bb_middle": last(bb_m),
        "bb_lower": last(bb_l),
        "atr": last(atr_v),
        "close": closes[-1] if closes else None,
        "prev_close": closes[-2] if len(closes) > 1 else None,
    }
    return {
        "series": {
            "rsi": rsi_v,
            "macd": macd_line,
            "macd_signal": macd_sig,
            "macd_hist": macd_hist,
            "sma20": sma20,
            "sma50": sma50,
            "ema20": ema20,
            "ema50": ema50,
            "bb_upper": bb_u,
            "bb_middle": bb_m,
            "bb_lower": bb_l,
            "atr": atr_v,
        },
        "snapshot": snap,
    }
