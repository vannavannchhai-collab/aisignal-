-- NEXA Signal Desk  ·  MySQL 8+ equivalent of schema.sql
CREATE TABLE users (
    id               BIGINT PRIMARY KEY AUTO_INCREMENT,
    username         VARCHAR(64)  NOT NULL UNIQUE,
    email            VARCHAR(255) UNIQUE,
    password_hash    VARCHAR(255),
    display_name     VARCHAR(128) NOT NULL,
    language         VARCHAR(8)   NOT NULL DEFAULT 'km',
    timezone         VARCHAR(64)  NOT NULL DEFAULT 'Asia/Phnom_Penh',
    telegram_chat_id VARCHAR(64),
    telegram_enabled TINYINT(1)   NOT NULL DEFAULT 0,
    role             VARCHAR(16)  NOT NULL DEFAULT 'trader',
    is_active        TINYINT(1)   NOT NULL DEFAULT 1,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login_at    DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE watchlists (
    id         BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id    BIGINT      NOT NULL,
    symbol     VARCHAR(32) NOT NULL,
    sort_order INT         NOT NULL DEFAULT 0,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, symbol),
    CONSTRAINT fk_wl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE accounts (
    id         BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id    BIGINT        NOT NULL,
    name       VARCHAR(64)   NOT NULL DEFAULT 'Paper',
    currency   VARCHAR(8)    NOT NULL DEFAULT 'USD',
    balance    DECIMAL(18,2) NOT NULL DEFAULT 10000.00,
    equity     DECIMAL(18,2) NOT NULL DEFAULT 10000.00,
    created_at DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, name),
    CONSTRAINT fk_acc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE candles (
    id         BIGINT PRIMARY KEY AUTO_INCREMENT,
    symbol     VARCHAR(32)    NOT NULL,
    timeframe  VARCHAR(8)     NOT NULL,
    open_time  BIGINT         NOT NULL,
    open       DECIMAL(18,8)  NOT NULL,
    high       DECIMAL(18,8)  NOT NULL,
    low        DECIMAL(18,8)  NOT NULL,
    close      DECIMAL(18,8)  NOT NULL,
    volume     DECIMAL(28,8)  NOT NULL,
    UNIQUE (symbol, timeframe, open_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE signals (
    id                   BIGINT PRIMARY KEY AUTO_INCREMENT,
    symbol               VARCHAR(32)    NOT NULL,
    timeframe            VARCHAR(8)     NOT NULL,
    side                 VARCHAR(8)     NOT NULL,
    strategy             VARCHAR(64)    NOT NULL,
    confidence           DECIMAL(5,2)   NOT NULL,
    price                DECIMAL(18,8)  NOT NULL,
    rsi                  DECIMAL(8,4),
    macd                 DECIMAL(18,8),
    macd_signal          DECIMAL(18,8),
    macd_hist            DECIMAL(18,8),
    sma_fast             DECIMAL(18,8),
    sma_slow             DECIMAL(18,8),
    ema_fast             DECIMAL(18,8),
    ema_slow             DECIMAL(18,8),
    bb_upper             DECIMAL(18,8),
    bb_middle            DECIMAL(18,8),
    bb_lower             DECIMAL(18,8),
    atr                  DECIMAL(18,8),
    take_profit          DECIMAL(18,8),
    stop_loss            DECIMAL(18,8),
    reasons_json         TEXT           NOT NULL,
    status               VARCHAR(16)    NOT NULL DEFAULT 'active',
    telegram_sent        TINYINT(1)     NOT NULL DEFAULT 0,
    telegram_message_id  VARCHAR(64),
    candle_time          BIGINT,
    created_at           DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_signals_candle (symbol, timeframe, side, candle_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE positions (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    account_id    BIGINT        NOT NULL,
    signal_id     BIGINT,
    symbol        VARCHAR(32)   NOT NULL,
    side          VARCHAR(8)    NOT NULL,
    quantity      DECIMAL(18,8) NOT NULL,
    entry_price   DECIMAL(18,8) NOT NULL,
    current_price DECIMAL(18,8),
    stop_loss     DECIMAL(18,8),
    take_profit   DECIMAL(18,8),
    realized_pnl  DECIMAL(18,2) NOT NULL DEFAULT 0,
    status        VARCHAR(16)   NOT NULL DEFAULT 'open',
    opened_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at     DATETIME NULL,
    CONSTRAINT fk_pos_acc FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
    CONSTRAINT fk_pos_sig FOREIGN KEY (signal_id) REFERENCES signals(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE telegram_logs (
    id        BIGINT PRIMARY KEY AUTO_INCREMENT,
    signal_id BIGINT,
    chat_id   VARCHAR(64),
    payload   TEXT,
    status    VARCHAR(16) NOT NULL DEFAULT 'queued',
    error     TEXT,
    sent_at   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_tg_sig FOREIGN KEY (signal_id) REFERENCES signals(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE app_settings (
    `key`      VARCHAR(64) PRIMARY KEY,
    value      TEXT,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
