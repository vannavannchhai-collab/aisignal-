"""
NEXA Telegram command bot
=========================
Long-polls Telegram for operator commands and pushes the same
BUY/SELL tickets the desk generates.

  /start     welcome
  /signals   last 5 tickets
  /status    desk health
  /subscribe save this chat id as the delivery channel

Run (after the API is up):
  TELEGRAM_BOT_TOKEN=123:abc python bot.py

The dashboard can send without this process — this file is the
interactive bot. Delivery of new signals is handled inside
app/telegram_bot.py whenever the scanner fires.
"""
from __future__ import annotations

import time
import sys
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from app import database as db  # noqa: E402
from app import telegram_bot  # noqa: E402
from app.config import TELEGRAM_BOT_TOKEN  # noqa: E402
from app.database import init_db  # noqa: E402


def token() -> str:
    init_db()
    return (db.get_setting("telegram_bot_token", TELEGRAM_BOT_TOKEN) or TELEGRAM_BOT_TOKEN).strip()


def api(method: str, payload: dict | None = None) -> dict:
    t = token()
    if not t:
        raise SystemExit("No TELEGRAM_BOT_TOKEN. Set env or save it on the Telegram page.")
    url = f"https://api.telegram.org/bot{t}/{method}"
    with httpx.Client(timeout=35.0) as client:
        r = client.post(url, json=payload or {})
        return r.json()


def handle(msg: dict) -> None:
    chat = msg.get("chat") or {}
    chat_id = str(chat.get("id", ""))
    text = (msg.get("text") or "").strip()
    if not text:
        return
    cmd = text.split()[0].split("@")[0].lower()

    if cmd in ("/start", "/help"):
        body = (
            "<b>NEXA Signal Desk</b>\n"
            "បូតសញ្ញាទិញ/លក់។\n\n"
            "/signals — សញ្ញាចុងក្រោយ\n"
            "/status — ស្ថានភាពផ្ទាំង\n"
            "/subscribe — ទទួលសារស្វ័យប្រវត្តិនៅ chat នេះ"
        )
        api("sendMessage", {"chat_id": chat_id, "text": body, "parse_mode": "HTML"})
        return

    if cmd == "/subscribe":
        telegram_bot.save_config(None, chat_id)
        api(
            "sendMessage",
            {
                "chat_id": chat_id,
                "text": f"បានចុះឈ្មោះ chat <code>{chat_id}</code>។ សញ្ញាថ្មីនឹងមកដល់ទីនេះ។",
                "parse_mode": "HTML",
            },
        )
        return

    if cmd == "/signals":
        rows = db.list_signals(limit=5)
        if not rows:
            api("sendMessage", {"chat_id": chat_id, "text": "មិនទាន់មានសញ្ញា។"})
            return
        for s in reversed(rows):
            html = telegram_bot.format_signal_html(s, lang="km")
            api("sendMessage", {"chat_id": chat_id, "text": html, "parse_mode": "HTML"})
        return

    if cmd == "/status":
        st = db.stats_overview()
        body = (
            f"<b>NEXA status</b>\n"
            f"Signals: {st['signals_total']}  (buy {st['signals_buy']} / sell {st['signals_sell']})\n"
            f"Today: {st['signals_today']}\n"
            f"Win rate: {st['win_rate']:.0f}%"
        )
        api("sendMessage", {"chat_id": chat_id, "text": body, "parse_mode": "HTML"})


def main() -> None:
    init_db()
    print("NEXA telegram bot polling…")
    offset = 0
    while True:
        try:
            data = api("getUpdates", {"timeout": 25, "offset": offset})
            for upd in data.get("result") or []:
                offset = int(upd["update_id"]) + 1
                if "message" in upd:
                    handle(upd["message"])
        except KeyboardInterrupt:
            break
        except Exception as exc:  # noqa: BLE001
            print("poll error:", exc)
            time.sleep(3)


if __name__ == "__main__":
    main()
