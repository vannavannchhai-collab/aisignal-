/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#05060a",
          900: "#080a10",
          850: "#0c0f16",
          800: "#12161f",
          700: "#1a2030",
          600: "#243044",
        },
        gold: {
          300: "#f3d48a",
          400: "#e8c36a",
          500: "#c9a227",
        },
        teal: {
          300: "#7ef0d6",
          400: "#4ee0c5",
          500: "#1ec9ab",
        },
        coral: {
          400: "#ff6b81",
          500: "#e23d58",
        },
      },
      fontFamily: {
        display: ["Syne", "Kantumruy Pro", "sans-serif"],
        sans: ["IBM Plex Sans", "Kantumruy Pro", "sans-serif"],
        khmer: ["Kantumruy Pro", "IBM Plex Sans", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
      boxShadow: {
        desk: "0 30px 80px -40px rgba(0,0,0,0.8)",
        glow: "0 0 40px -12px rgba(78,224,197,0.35)",
      },
      backgroundImage: {
        grid: "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
      },
    },
  },
  plugins: [],
};
