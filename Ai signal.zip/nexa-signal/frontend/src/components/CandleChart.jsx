import { useEffect, useRef } from "react";
import { createChart, ColorType, CrosshairMode } from "lightweight-charts";

export default function CandleChart({ candles = [], height = 420 }) {
  const wrap = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    if (!wrap.current) return undefined;
    const el = wrap.current;
    const chart = createChart(el, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#8b93a7",
        fontFamily: "JetBrains Mono, IBM Plex Sans, sans-serif",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "rgba(255,255,255,0.04)" },
        horzLines: { color: "rgba(255,255,255,0.04)" },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { color: "rgba(232,195,106,0.35)", width: 1, style: 3 },
        horzLine: { color: "rgba(232,195,106,0.35)", width: 1, style: 3 },
      },
      rightPriceScale: {
        borderColor: "rgba(255,255,255,0.06)",
        scaleMargins: { top: 0.08, bottom: 0.18 },
      },
      timeScale: {
        borderColor: "rgba(255,255,255,0.06)",
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
    });

    const candleSeries = chart.addCandlestickSeries({
      upColor: "#4ee0c5",
      downColor: "#ff6b81",
      borderUpColor: "#4ee0c5",
      borderDownColor: "#ff6b81",
      wickUpColor: "#7ef0d6",
      wickDownColor: "#ff8a9b",
    });
    const emaSeries = chart.addLineSeries({
      color: "rgba(232,195,106,0.9)",
      lineWidth: 2,
      priceLineVisible: false,
      lastValueVisible: true,
      title: "EMA20",
    });
    const smaSeries = chart.addLineSeries({
      color: "rgba(125, 160, 255, 0.85)",
      lineWidth: 1,
      priceLineVisible: false,
      lastValueVisible: false,
      title: "SMA50",
    });
    const volSeries = chart.addHistogramSeries({
      priceFormat: { type: "volume" },
      priceScaleId: "vol",
    });
    chart.priceScale("vol").applyOptions({
      scaleMargins: { top: 0.82, bottom: 0 },
      borderVisible: false,
    });

    chartRef.current = { chart, candleSeries, emaSeries, smaSeries, volSeries };

    const onResize = () => {
      if (!el) return;
      chart.applyOptions({ width: el.clientWidth, height: el.clientHeight });
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(el);

    return () => {
      ro.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, []);

  useEffect(() => {
    const refs = chartRef.current;
    if (!refs || !candles.length) return;
    const ohlc = candles
      .filter((c) => c.time && c.close != null)
      .map((c) => ({
        time: c.time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
    refs.candleSeries.setData(ohlc);
    refs.emaSeries.setData(
      candles.filter((c) => c.ema20 != null).map((c) => ({ time: c.time, value: c.ema20 }))
    );
    refs.smaSeries.setData(
      candles.filter((c) => c.sma50 != null).map((c) => ({ time: c.time, value: c.sma50 }))
    );
    refs.volSeries.setData(
      candles.map((c) => ({
        time: c.time,
        value: c.volume || 0,
        color: c.close >= c.open ? "rgba(78,224,197,0.28)" : "rgba(255,107,129,0.28)",
      }))
    );
    refs.chart.timeScale().fitContent();
  }, [candles]);

  return (
    <div
      ref={wrap}
      style={{ height }}
      className="w-full rounded-md"
    />
  );
}
