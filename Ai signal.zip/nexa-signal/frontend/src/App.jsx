import { useCallback, useEffect, useMemo, useState } from "react";
import CandleChart from "./components/CandleChart.jsx";
import { api, fmtPct, fmtPx, fmtUsd, timeAgo } from "./api.js";
import { copy } from "./i18n.js";

const NAV = [
  { id: "desk", icon: "01" },
  { id: "signals", icon: "02" },
  { id: "portfolio", icon: "03" },
  { id: "telegram", icon: "04" },
  { id: "schema", icon: "05" },
  { id: "settings", icon: "06" },
];

const TFS = ["15m", "1H", "4H", "1D"];

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return now;
}

function phnomParts(date) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Phnom_Penh",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    weekday: "short",
    day: "2-digit",
    month: "short",
  });
  return fmt.format(date);
}

function parseReasons(raw) {
  try {
    const v = typeof raw === "string" ? JSON.parse(raw) : raw;
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}

function SideBadge({ side, lang }) {
  const buy = side === "BUY";
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-sm px-2 py-0.5 font-mono text-[10px] tracking-[0.18em] ${
        buy ? "bg-teal-400/15 text-teal-300" : "bg-coral-400/15 text-coral-400"
      }`}
    >
      {buy ? copy[lang].buy : copy[lang].sell}
    </span>
  );
}

function Gauge({ value, label, lo = 30, hi = 70 }) {
  const v = value == null ? 50 : Math.max(0, Math.min(100, value));
  const r = 34;
  const c = 2 * Math.PI * r;
  const dash = (v / 100) * c;
  const color = v < lo ? "#4ee0c5" : v > hi ? "#ff6b81" : "#e8c36a";
  return (
    <div className="flex flex-col items-center">
      <svg width="92" height="92" viewBox="0 0 92 92">
        <circle cx="46" cy="46" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="7" />
        <circle
          className="gauge-arc"
          cx="46"
          cy="46"
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
        />
        <text
          x="46"
          y="50"
          textAnchor="middle"
          fill="#f4f6fb"
          fontFamily="JetBrains Mono"
          fontSize="16"
        >
          {value == null ? "—" : v.toFixed(1)}
        </text>
      </svg>
      <div className="mt-1 text-[10px] uppercase tracking-[0.22em] text-white/40">{label}</div>
    </div>
  );
}

function StatTile({ kicker, value, sub, tone = "default" }) {
  const color =
    tone === "up" ? "text-teal-300" : tone === "down" ? "text-coral-400" : "text-white";
  return (
    <div className="corner-ticks relative overflow-hidden rounded-md border border-white/5 bg-ink-800/70 px-4 py-3">
      <div className="text-[10px] uppercase tracking-[0.22em] text-gold-400/80">{kicker}</div>
      <div className={`mt-2 font-mono text-2xl tabular ${color}`}>{value}</div>
      {sub && <div className="mt-1 text-xs text-white/40">{sub}</div>}
    </div>
  );
}

function SignalTicket({ s, lang, onTake, onPing, compact = false }) {
  const reasons = parseReasons(s.reasons_json);
  const buy = s.side === "BUY";
  return (
    <article
      className={`relative overflow-hidden rounded-md border border-white/5 bg-ink-800/80 ${
        compact ? "p-3" : "p-4"
      }`}
    >
      <span
        className={`absolute inset-y-0 left-0 w-[3px] ${buy ? "bg-teal-400" : "bg-coral-400"}`}
      />
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display text-lg tracking-wide">{s.symbol}</span>
            <SideBadge side={s.side} lang={lang} />
            <span className="font-mono text-[10px] text-white/35">{s.timeframe}</span>
          </div>
          <div className="mt-1 text-xs text-white/45">
            {s.strategy} · {timeAgo(s.created_at, lang)}
          </div>
        </div>
        <div className="text-right">
          <div className="font-mono text-lg tabular">{fmtPx(s.price)}</div>
          <div className="text-[10px] uppercase tracking-[0.16em] text-gold-400">
            {copy[lang].confidence} {Number(s.confidence).toFixed(0)}%
          </div>
        </div>
      </div>
      {!compact && (
        <>
          <div className="mt-3 grid grid-cols-3 gap-2 font-mono text-[11px] text-white/60">
            <div>RSI {s.rsi != null ? Number(s.rsi).toFixed(1) : "—"}</div>
            <div>
              TP {fmtPx(s.take_profit)}
            </div>
            <div>
              SL {fmtPx(s.stop_loss)}
            </div>
          </div>
          <ul className="mt-3 space-y-1 text-xs text-white/55">
            {reasons.slice(0, 3).map((r, i) => (
              <li key={i}>▸ {lang === "km" ? r.km || r.en : r.en}</li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            {onTake && (
              <button
                onClick={() => onTake(s)}
                className="rounded-sm border border-teal-400/30 bg-teal-400/10 px-3 py-1.5 text-[11px] uppercase tracking-[0.16em] text-teal-300 hover:bg-teal-400/20"
              >
                {copy[lang].take}
              </button>
            )}
            {onPing && (
              <button
                onClick={() => onPing(s)}
                className="rounded-sm border border-white/10 px-3 py-1.5 text-[11px] uppercase tracking-[0.16em] text-white/60 hover:text-white"
              >
                Telegram
              </button>
            )}
          </div>
        </>
      )}
    </article>
  );
}

export default function App() {
  const [lang, setLang] = useState(() => localStorage.getItem("nexa-lang") || "km");
  const [page, setPage] = useState("desk");
  const [health, setHealth] = useState(null);
  const [markets, setMarkets] = useState([]);
  const [signals, setSignals] = useState([]);
  const [stats, setStats] = useState(null);
  const [portfolio, setPortfolio] = useState(null);
  const [symbol, setSymbol] = useState("BTC-USD");
  const [tf, setTf] = useState("1H");
  const [analysis, setAnalysis] = useState(null);
  const [busy, setBusy] = useState(false);
  const [tg, setTg] = useState({ token: "", chat_id: "", status: null, logs: [] });
  const [schema, setSchema] = useState(null);
  const [toast, setToast] = useState("");
  const [notional, setNotional] = useState(1000);
  const clock = useClock();
  const txt = copy[lang];

  const ping = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2800);
  };

  const loadCore = useCallback(async () => {
    try {
      const [h, m, s, st, p] = await Promise.all([
        api.health(),
        api.markets(),
        api.signals({ limit: 80 }),
        api.stats(),
        api.portfolio(),
      ]);
      setHealth(h);
      setMarkets(m.markets || []);
      setSignals(s.signals || []);
      setStats(st.stats);
      setPortfolio(p);
    } catch (err) {
      ping(String(err.message || err));
    }
  }, []);

  const loadAnalysis = useCallback(async () => {
    try {
      const data = await api.analysis(symbol, tf);
      setAnalysis(data);
    } catch (err) {
      ping(String(err.message || err));
    }
  }, [symbol, tf]);

  useEffect(() => {
    loadCore();
    const id = setInterval(loadCore, 20000);
    return () => clearInterval(id);
  }, [loadCore]);

  useEffect(() => {
    loadAnalysis();
  }, [loadAnalysis]);

  useEffect(() => {
    localStorage.setItem("nexa-lang", lang);
    document.documentElement.lang = lang === "km" ? "km" : "en";
  }, [lang]);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.id === symbol) || markets[0],
    [markets, symbol]
  );

  const scan = async () => {
    setBusy(true);
    try {
      const res = await api.scan("all");
      ping(lang === "km" ? `សញ្ញាថ្មី ${res.count}` : `${res.count} new tickets`);
      await loadCore();
      await loadAnalysis();
    } catch (err) {
      ping(String(err.message || err));
    } finally {
      setBusy(false);
    }
  };

  const take = async (s) => {
    try {
      await api.trade(s.id, notional);
      ping(lang === "km" ? "បានបើកតំណែងក្រដាស" : "Paper ticket opened");
      setPortfolio(await api.portfolio());
      setPage("portfolio");
    } catch (err) {
      ping(String(err.message || err));
    }
  };

  const pingTg = async (s) => {
    try {
      const res = await api.telegramResend(s.id, lang);
      ping(res.mode === "live" ? "Telegram sent" : (lang === "km" ? "រក្សាក្នុងប្រអប់ចេញ" : "Queued to outbox"));
    } catch (err) {
      ping(String(err.message || err));
    }
  };

  const loadTelegram = async () => {
    const [st, logs] = await Promise.all([api.telegramStatus(), api.telegramLogs()]);
    setTg((prev) => ({
      ...prev,
      status: st,
      logs: logs.logs || [],
      chat_id: prev.chat_id || st.chat_id || "",
    }));
  };

  useEffect(() => {
    if (page === "telegram") loadTelegram().catch(() => {});
    if (page === "schema" && !schema) api.schema().then(setSchema).catch(() => {});
  }, [page]); // eslint-disable-line

  const acc = portfolio?.account;
  const unreal = portfolio?.unrealized_pnl || 0;

  return (
    <div className={`flex h-screen overflow-hidden bg-ink-950 text-[#e8ecf4] ${lang === "km" ? "font-khmer" : ""}`}>
      <aside className="flex w-[232px] shrink-0 flex-col border-r border-white/5 bg-ink-900/80 backdrop-blur">
        <div className="flex items-center gap-3 px-5 py-5">
          <img src="/nexa-mark.png" alt="NEXA" className="h-11 w-11 rounded-xl" />
          <div>
            <div className="font-display text-xl leading-none tracking-[0.18em]">NEXA</div>
            <div className="mt-1 text-[10px] uppercase tracking-[0.28em] text-gold-400/90">
              {txt.desk}
            </div>
          </div>
        </div>
        <nav className="mt-2 flex-1 space-y-1 px-3">
          {NAV.map((n) => {
            const active = page === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setPage(n.id)}
                className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm transition ${
                  active
                    ? "bg-white/5 text-white"
                    : "text-white/50 hover:bg-white/[0.03] hover:text-white/80"
                }`}
              >
                <span className="font-mono text-[10px] text-gold-400/80">{n.icon}</span>
                <span>{txt.nav[n.id]}</span>
              </button>
            );
          })}
        </nav>
        <div className="px-5 py-4 text-[11px] text-white/35">
          <div className="flex items-center gap-2">
            <span className="pulse-dot" />
            <span className="font-mono tracking-[0.2em] text-teal-300">{txt.live}</span>
          </div>
          <div className="mt-2">{txt.user}: demo</div>
          <div>{txt.tz}</div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-white/5 px-6 py-3">
          <div>
            <div className="text-[11px] uppercase tracking-[0.28em] text-white/40">{txt.tagline}</div>
            <div className="font-mono text-sm text-white/70">{phnomParts(clock)} · ICT</div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={scan}
              disabled={busy}
              className="rounded-sm border border-gold-400/40 bg-gold-400/10 px-4 py-2 text-[11px] uppercase tracking-[0.18em] text-gold-300 hover:bg-gold-400/20 disabled:opacity-50"
            >
              {busy ? txt.scanning : txt.scan}
            </button>
            <div className="flex overflow-hidden rounded-sm border border-white/10">
              {["km", "en"].map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`px-3 py-2 text-[11px] uppercase tracking-[0.16em] ${
                    lang === l ? "bg-white/10 text-white" : "text-white/40"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
        </header>

        <div className="overflow-hidden border-b border-white/5 bg-ink-900/50">
          <div className="ticker-track">
            {[...markets, ...markets].map((m, i) => {
              const up = m.change24h >= 0;
              return (
                <button
                  key={`${m.id}-${i}`}
                  onClick={() => {
                    setSymbol(m.id);
                    setPage("desk");
                  }}
                  className="flex items-center gap-3 border-r border-white/5 px-5 py-2 text-left"
                >
                  <span className="font-mono text-xs text-white/70">{m.base}</span>
                  <span className="font-mono text-xs tabular">{fmtPx(m.price)}</span>
                  <span className={`font-mono text-[11px] ${up ? "text-teal-300" : "text-coral-400"}`}>
                    {fmtPct(m.change24h)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <main className="scroll-thin min-h-0 flex-1 overflow-y-auto p-6">
          {page === "desk" && (
            <Desk
              txt={txt}
              lang={lang}
              markets={markets}
              signals={signals}
              stats={stats}
              acc={acc}
              unreal={unreal}
              symbol={symbol}
              setSymbol={setSymbol}
              tf={tf}
              setTf={setTf}
              analysis={analysis}
              selectedMarket={selectedMarket}
              take={take}
              pingTg={pingTg}
              health={health}
            />
          )}
          {page === "signals" && (
            <section>
              <h1 className="font-display text-3xl">{txt.blotter}</h1>
              <p className="mt-1 max-w-2xl text-sm text-white/45">{txt.engineNote}</p>
              <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {signals.length === 0 && (
                  <div className="col-span-full border border-dashed border-white/10 p-10 text-center text-white/40">
                    {txt.emptySignals}
                  </div>
                )}
                {signals.map((s) => (
                  <SignalTicket key={s.id} s={s} lang={lang} onTake={take} onPing={pingTg} />
                ))}
              </div>
            </section>
          )}
          {page === "portfolio" && (
            <Ledger
              txt={txt}
              lang={lang}
              portfolio={portfolio}
              notional={notional}
              setNotional={setNotional}
              onClose={async (id) => {
                await api.close(id);
                setPortfolio(await api.portfolio());
              }}
              onReset={async () => {
                setPortfolio(await api.reset());
                ping(lang === "km" ? "បានកំណត់ឡើងវិញ" : "Desk reset");
              }}
            />
          )}
          {page === "telegram" && (
            <Telegram
              txt={txt}
              lang={lang}
              tg={tg}
              setTg={setTg}
              onSave={async () => {
                const st = await api.telegramConfig({
                  token: tg.token || undefined,
                  chat_id: tg.chat_id || undefined,
                });
                setTg((p) => ({ ...p, status: st, token: "" }));
                ping(lang === "km" ? "បានរក្សាទុក" : "Saved");
              }}
              onTest={async () => {
                const res = await api.telegramTest(lang);
                ping(res.ok ? (res.mode === "live" ? "Sent" : txt.simulated) : res.error);
                loadTelegram();
              }}
            />
          )}
          {page === "schema" && <SchemaView txt={txt} schema={schema} />}
          {page === "settings" && (
            <section className="max-w-xl space-y-4">
              <h1 className="font-display text-3xl">{txt.nav.settings}</h1>
              <p className="text-sm text-white/50">{txt.settingsLead}</p>
              <div className="rounded-md border border-white/5 bg-ink-800/70 p-5">
                <div className="text-[10px] uppercase tracking-[0.2em] text-gold-400">{txt.language}</div>
                <div className="mt-3 flex gap-2">
                  {["km", "en"].map((l) => (
                    <button
                      key={l}
                      onClick={() => setLang(l)}
                      className={`rounded-sm border px-4 py-2 text-sm ${
                        lang === l ? "border-gold-400/50 bg-gold-400/10" : "border-white/10"
                      }`}
                    >
                      {l === "km" ? "ខ្មែរ" : "English"}
                    </button>
                  ))}
                </div>
                <p className="mt-4 text-xs leading-relaxed text-white/40">{txt.disclaimer}</p>
                <p className="mt-3 font-mono text-[11px] text-white/30">
                  scan {health?.scan_interval_sec || 60}s · last {health?.last_scan_at || "—"}
                </p>
              </div>
            </section>
          )}
        </main>

        <footer className="flex items-center justify-between border-t border-white/5 px-6 py-2 text-[11px] text-white/35">
          <span>{txt.disclaimer}</span>
          <span className="font-mono">NEXA · {txt.lastScan} {health?.last_scan_count ?? 0}</span>
        </footer>
      </div>

      {toast && (
        <div className="fixed bottom-6 right-6 z-50 rounded-md border border-gold-400/30 bg-ink-800 px-4 py-3 font-mono text-xs text-gold-300 shadow-desk">
          {toast}
        </div>
      )}
    </div>
  );
}

function Desk({
  txt,
  lang,
  markets,
  signals,
  stats,
  acc,
  unreal,
  symbol,
  setSymbol,
  tf,
  setTf,
  analysis,
  selectedMarket,
  take,
  pingTg,
  health,
}) {
  const snap = analysis?.snapshot || {};
  const bias = analysis?.bias || "NEUTRAL";
  const biasLabel = bias === "BULLISH" ? txt.bullish : bias === "BEARISH" ? txt.bearish : txt.neutral;
  const biasColor =
    bias === "BULLISH" ? "text-teal-300" : bias === "BEARISH" ? "text-coral-400" : "text-gold-300";

  return (
    <div className="space-y-5">
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        <StatTile
          kicker={txt.equity}
          value={fmtUsd(acc?.equity)}
          sub={`${txt.cash} ${fmtUsd(acc?.balance)}`}
        />
        <StatTile
          kicker={txt.unrealized}
          value={fmtUsd(unreal)}
          tone={unreal >= 0 ? "up" : "down"}
          sub={txt.account}
        />
        <StatTile kicker={txt.today} value={stats?.signals_today ?? 0} sub={`${stats?.signals_total ?? 0} total`} />
        <StatTile
          kicker={txt.winRate}
          value={`${Number(stats?.win_rate || 0).toFixed(0)}%`}
          sub={`${stats?.closed_trades ?? 0} closed`}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.7fr)_minmax(320px,1fr)]">
        <section className="rounded-md border border-white/5 bg-ink-800/50 p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-[10px] uppercase tracking-[0.22em] text-white/35">{txt.analysis}</div>
              <div className="flex items-baseline gap-3">
                <h2 className="font-display text-2xl">{symbol}</h2>
                <span className="font-mono text-xl tabular">{fmtPx(selectedMarket?.price)}</span>
                <span
                  className={`font-mono text-sm ${
                    (selectedMarket?.change24h || 0) >= 0 ? "text-teal-300" : "text-coral-400"
                  }`}
                >
                  {fmtPct(selectedMarket?.change24h)}
                </span>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                className="rounded-sm border border-white/10 bg-ink-900 px-2 py-1.5 font-mono text-xs"
              >
                {markets.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.base}/{m.quote}
                  </option>
                ))}
              </select>
              <div className="flex overflow-hidden rounded-sm border border-white/10">
                {TFS.map((x) => (
                  <button
                    key={x}
                    onClick={() => setTf(x)}
                    className={`px-2.5 py-1.5 font-mono text-[11px] ${
                      tf === x ? "bg-white/10 text-white" : "text-white/40"
                    }`}
                  >
                    {x}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <CandleChart candles={analysis?.candles || []} height={430} />
        </section>

        <div className="space-y-4">
          <section className="rounded-md border border-white/5 bg-ink-800/50 p-4">
            <div className="flex items-center justify-between">
              <div className="text-[10px] uppercase tracking-[0.22em] text-gold-400">{txt.generated}</div>
              <div className={`font-mono text-xs uppercase tracking-[0.16em] ${biasColor}`}>{biasLabel}</div>
            </div>
            <div className="mt-3 flex justify-around">
              <Gauge value={snap.rsi} label="RSI" />
              <div className="flex flex-col items-center justify-center">
                <div className="font-mono text-2xl tabular">
                  {snap.macd_hist == null
                    ? "—"
                    : `${snap.macd_hist > 0 ? "+" : ""}${Number(snap.macd_hist).toPrecision(3)}`}
                </div>
                <div className="mt-1 text-[10px] uppercase tracking-[0.2em] text-white/40">MACD hist</div>
                <div className="mt-3 font-mono text-[11px] text-white/50">
                  {txt.ema}{" "}
                  {snap.ema20 && snap.ema50
                    ? snap.ema20 > snap.ema50
                      ? "↑"
                      : "↓"
                    : "—"}
                </div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 font-mono text-[11px] text-white/55">
              <div>buy {analysis?.scores?.buy ?? 0}</div>
              <div>sell {analysis?.scores?.sell ?? 0}</div>
              <div>SMA20 {fmtPx(snap.sma20)}</div>
              <div>SMA50 {fmtPx(snap.sma50)}</div>
            </div>
          </section>

          <section className="rounded-md border border-white/5 bg-ink-800/50 p-4">
            <div className="mb-3 text-[10px] uppercase tracking-[0.22em] text-white/40">{txt.heatmap}</div>
            <div className="grid grid-cols-5 gap-1.5">
              {markets.map((m) => {
                const rsi = m.rsi;
                const bg =
                  rsi == null
                    ? "bg-white/5"
                    : rsi < 30
                    ? "bg-teal-400/30"
                    : rsi > 70
                    ? "bg-coral-400/30"
                    : "bg-gold-400/10";
                return (
                  <button
                    key={m.id}
                    onClick={() => setSymbol(m.id)}
                    className={`rounded-sm px-1 py-2 text-center ${bg} ${
                      symbol === m.id ? "ring-1 ring-gold-400/60" : ""
                    }`}
                  >
                    <div className="font-mono text-[10px]">{m.base}</div>
                    <div className="font-mono text-[10px] text-white/70">
                      {rsi == null ? "—" : rsi.toFixed(0)}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          <div className="space-y-2">
            {signals.slice(0, 3).map((s) => (
              <SignalTicket key={s.id} s={s} lang={lang} onTake={take} onPing={pingTg} compact={false} />
            ))}
          </div>
        </div>
      </div>
      <p className="text-[11px] text-white/30">
        {txt.lastScan}: {health?.last_scan_at || "—"} · {health?.telegram?.mode}
      </p>
    </div>
  );
}

function Ledger({ txt, lang, portfolio, notional, setNotional, onClose, onReset }) {
  const open = portfolio?.open || [];
  const closed = portfolio?.closed || [];
  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">{txt.nav.portfolio}</h1>
          <p className="mt-1 text-sm text-white/45">
            {txt.equity} {fmtUsd(portfolio?.equity)} · {txt.cash} {fmtUsd(portfolio?.cash)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] uppercase tracking-[0.16em] text-white/40">
            {txt.notional}
            <input
              type="number"
              min="50"
              value={notional}
              onChange={(e) => setNotional(Number(e.target.value))}
              className="ml-2 w-28 rounded-sm border border-white/10 bg-ink-900 px-2 py-1 font-mono text-xs"
            />
          </label>
          <button
            onClick={onReset}
            className="rounded-sm border border-white/10 px-3 py-2 text-[11px] uppercase tracking-[0.16em] text-white/50 hover:text-white"
          >
            {txt.reset}
          </button>
        </div>
      </div>
      <h2 className="text-[10px] uppercase tracking-[0.22em] text-gold-400">{txt.openPos}</h2>
      <div className="overflow-hidden rounded-md border border-white/5">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/[0.03] font-mono text-[10px] uppercase tracking-[0.16em] text-white/40">
            <tr>
              <th className="px-3 py-2">Symbol</th>
              <th className="px-3 py-2">Side</th>
              <th className="px-3 py-2">Qty</th>
              <th className="px-3 py-2">Entry</th>
              <th className="px-3 py-2">Mark</th>
              <th className="px-3 py-2">P&L</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {open.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-8 text-center text-white/35">
                  {txt.emptyPos}
                </td>
              </tr>
            )}
            {open.map((p) => {
              const px = p.current_price || p.entry_price;
              const pnl =
                p.side === "BUY"
                  ? (px - p.entry_price) * p.quantity
                  : (p.entry_price - px) * p.quantity;
              return (
                <tr key={p.id} className="border-t border-white/5">
                  <td className="px-3 py-2 font-mono">{p.symbol}</td>
                  <td className="px-3 py-2">
                    <SideBadge side={p.side} lang={lang} />
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">{Number(p.quantity).toPrecision(4)}</td>
                  <td className="px-3 py-2 font-mono">{fmtPx(p.entry_price)}</td>
                  <td className="px-3 py-2 font-mono">{fmtPx(px)}</td>
                  <td className={`px-3 py-2 font-mono ${pnl >= 0 ? "text-teal-300" : "text-coral-400"}`}>
                    {fmtUsd(pnl)}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button
                      onClick={() => onClose(p.id)}
                      className="text-[11px] uppercase tracking-[0.14em] text-white/50 hover:text-white"
                    >
                      {txt.close}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <h2 className="text-[10px] uppercase tracking-[0.22em] text-gold-400">Closed</h2>
      <div className="space-y-1 font-mono text-xs text-white/50">
        {closed.map((p) => (
          <div key={p.id} className="flex justify-between border-b border-white/5 py-2">
            <span>
              {p.symbol} {p.side}
            </span>
            <span className={p.realized_pnl >= 0 ? "text-teal-300" : "text-coral-400"}>
              {fmtUsd(p.realized_pnl)}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Telegram({ txt, lang, tg, setTg, onSave, onTest }) {
  const live = tg.status?.configured;
  return (
    <section className="grid gap-6 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <div>
        <h1 className="font-display text-3xl">{txt.telegramTitle}</h1>
        <p className="mt-2 max-w-md text-sm leading-relaxed text-white/50">{txt.connectHint}</p>
        <div className="mt-5 space-y-3 rounded-md border border-white/5 bg-ink-800/60 p-5">
          <div className="text-[10px] uppercase tracking-[0.2em] text-gold-400">
            {live ? txt.liveMode : txt.simulated}
          </div>
          <label className="block text-xs text-white/50">
            {txt.token}
            <input
              type="password"
              value={tg.token}
              placeholder={tg.status?.has_token ? "•••• stored" : "123456:ABC…"}
              onChange={(e) => setTg((p) => ({ ...p, token: e.target.value }))}
              className="mt-1 w-full rounded-sm border border-white/10 bg-ink-900 px-3 py-2 font-mono text-sm"
            />
          </label>
          <label className="block text-xs text-white/50">
            {txt.chat}
            <input
              value={tg.chat_id}
              placeholder="-100…"
              onChange={(e) => setTg((p) => ({ ...p, chat_id: e.target.value }))}
              className="mt-1 w-full rounded-sm border border-white/10 bg-ink-900 px-3 py-2 font-mono text-sm"
            />
          </label>
          <div className="flex gap-2 pt-2">
            <button
              onClick={onSave}
              className="rounded-sm border border-gold-400/40 bg-gold-400/10 px-4 py-2 text-[11px] uppercase tracking-[0.16em] text-gold-300"
            >
              {txt.save}
            </button>
            <button
              onClick={onTest}
              className="rounded-sm border border-white/10 px-4 py-2 text-[11px] uppercase tracking-[0.16em]"
            >
              {txt.test}
            </button>
          </div>
        </div>
      </div>
      <div>
        <div className="mb-3 text-[10px] uppercase tracking-[0.22em] text-white/40">{txt.logs}</div>
        <div className="scroll-thin max-h-[70vh] space-y-3 overflow-y-auto">
          {(tg.logs || []).map((log) => (
            <pre
              key={log.id}
              className="whitespace-pre-wrap rounded-md border border-white/5 bg-[#0b0e14] p-4 font-mono text-[11px] leading-relaxed text-white/70"
            >
              <div className="mb-2 text-[10px] uppercase tracking-[0.16em] text-gold-400/80">
                {log.status} · {log.sent_at}
              </div>
              {log.payload}
            </pre>
          ))}
        </div>
      </div>
    </section>
  );
}

function SchemaView({ txt, schema }) {
  return (
    <section className="space-y-5">
      <div>
        <h1 className="font-display text-3xl">{txt.schemaTitle}</h1>
        <p className="mt-2 max-w-2xl text-sm text-white/50">{txt.schemaLead}</p>
      </div>
      <div className="overflow-x-auto rounded-md border border-white/5 bg-ink-800/40 p-6">
        <svg viewBox="0 0 980 420" className="h-auto w-full min-w-[760px]">
          {[
            { x: 20, y: 40, n: "users", d: "operator · language · chat id" },
            { x: 250, y: 40, n: "accounts", d: "paper cash / equity" },
            { x: 480, y: 40, n: "watchlists", d: "per-user symbols" },
            { x: 20, y: 200, n: "signals", d: "BUY/SELL + indicators" },
            { x: 250, y: 200, n: "positions", d: "tickets linked to signals" },
            { x: 480, y: 200, n: "telegram_logs", d: "delivery audit" },
            { x: 710, y: 40, n: "candles", d: "OHLCV cache" },
            { x: 710, y: 200, n: "app_settings", d: "bot token · flags" },
          ].map((b) => (
            <g key={b.n}>
              <rect
                x={b.x}
                y={b.y}
                width="210"
                height="96"
                rx="6"
                fill="#12161f"
                stroke="rgba(232,195,106,0.35)"
              />
              <text x={b.x + 16} y={b.y + 38} fill="#e8c36a" fontFamily="Syne" fontSize="16">
                {b.n}
              </text>
              <text x={b.x + 16} y={b.y + 64} fill="#8b93a7" fontFamily="IBM Plex Sans" fontSize="12">
                {b.d}
              </text>
            </g>
          ))}
          <path
            d="M230 88 H250 M230 248 H250 M460 88 H480 M460 248 H480 M125 136 V200"
            stroke="rgba(78,224,197,0.45)"
            fill="none"
          />
        </svg>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {(schema?.tables || []).map((t) => (
          <div key={t.name} className="rounded-md border border-white/5 bg-ink-800/50 p-4">
            <div className="font-mono text-sm text-gold-300">{t.name}</div>
            <div className="mt-1 text-xs text-white/50">{t.role}</div>
          </div>
        ))}
      </div>
      {schema?.sql && (
        <pre className="scroll-thin max-h-[420px] overflow-auto rounded-md border border-white/5 bg-[#080b11] p-4 font-mono text-[11px] leading-relaxed text-white/60">
          {schema.sql}
        </pre>
      )}
    </section>
  );
}
