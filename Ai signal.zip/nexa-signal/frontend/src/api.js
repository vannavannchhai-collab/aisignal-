const json = async (res) => {
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || JSON.stringify(body);
    } catch {
      /* ignore */
    }
    throw new Error(detail);
  }
  return res.json();
};

export const api = {
  health: () => fetch("/api/health").then(json),
  symbols: () => fetch("/api/symbols").then(json),
  markets: () => fetch("/api/markets").then(json),
  analysis: (symbol, tf = "1H") =>
    fetch(`/api/markets/${encodeURIComponent(symbol)}/analysis?tf=${tf}`).then(json),
  signals: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return fetch(`/api/signals${q ? `?${q}` : ""}`).then(json);
  },
  scan: (tf = "all") =>
    fetch(`/api/signals/scan?tf=${tf}`, { method: "POST" }).then(json),
  portfolio: () => fetch("/api/portfolio").then(json),
  trade: (signal_id, notional_usd = 1000) =>
    fetch("/api/portfolio/trade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ signal_id, notional_usd }),
    }).then(json),
  close: (position_id) =>
    fetch("/api/portfolio/close", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ position_id }),
    }).then(json),
  reset: () => fetch("/api/portfolio/reset", { method: "POST" }).then(json),
  stats: () => fetch("/api/stats").then(json),
  telegramStatus: () => fetch("/api/telegram/status").then(json),
  telegramConfig: (body) =>
    fetch("/api/telegram/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then(json),
  telegramTest: (lang = "km") =>
    fetch(`/api/telegram/test?lang=${lang}`, { method: "POST" }).then(json),
  telegramResend: (id, lang = "km") =>
    fetch(`/api/telegram/resend/${id}?lang=${lang}`, { method: "POST" }).then(json),
  telegramLogs: () => fetch("/api/telegram/logs").then(json),
  schema: () => fetch("/api/schema").then(json),
};

export const fmtPx = (n) => {
  if (n == null || Number.isNaN(Number(n))) return "—";
  const v = Number(n);
  if (v >= 1000) return v.toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (v >= 1) return v.toLocaleString(undefined, { maximumFractionDigits: 4 });
  return v.toLocaleString(undefined, { maximumFractionDigits: 6 });
};

export const fmtUsd = (n) => {
  if (n == null || Number.isNaN(Number(n))) return "—";
  return Number(n).toLocaleString(undefined, {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  });
};

export const fmtPct = (n, digits = 2) => {
  if (n == null || Number.isNaN(Number(n))) return "—";
  const v = Number(n);
  const sign = v > 0 ? "+" : "";
  return `${sign}${v.toFixed(digits)}%`;
};

export const timeAgo = (iso, lang = "en") => {
  if (!iso) return "—";
  const t = new Date(iso.replace(" ", "T") + (iso.endsWith("Z") ? "" : "Z"));
  const s = Math.max(0, (Date.now() - t.getTime()) / 1000);
  if (s < 60) return lang === "km" ? "មុននេះបន្តិច" : "just now";
  if (s < 3600) {
    const m = Math.floor(s / 60);
    return lang === "km" ? `${m} នាទីមុន` : `${m}m ago`;
  }
  if (s < 86400) {
    const h = Math.floor(s / 3600);
    return lang === "km" ? `${h} ម៉ោងមុន` : `${h}h ago`;
  }
  const d = Math.floor(s / 86400);
  return lang === "km" ? `${d} ថ្ងៃមុន` : `${d}d ago`;
};
